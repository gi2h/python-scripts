/**
 * turnstile.js — v9 FINAL
 * + Deteksi "silent reject" (iframe detach tanpa token)
 * + Log yang jelas untuk diagnosis IP
 */

"use strict";

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");

  let baseUrl = domain;
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = "https://" + baseUrl;
  const origin = new URL(baseUrl).origin;

  const totalTimeout = global.timeOut || 90000;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    let capturedToken = null;
    let frameDetachedAt = null;
    let mainFrameLoadAt = null;
    let iframeCount = 0;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, totalTimeout + 5000);

    (async () => {
      // ── Listeners ───────────────────────────────
      const onMessage = (msg) => {
        try {
          const text = typeof msg === "string" ? msg : JSON.stringify(msg);
          if (!text) return;
          const m = text.match(/0\.[A-Za-z0-9_\-]{100,}/);
          if (m) {
            capturedToken = m[0];
            console.log(`[ts-msg] 🎯 token via postMessage (${capturedToken.length} chars)`);
          }
        } catch {}
      };

      const onFrameDetached = (frame) => {
        try {
          const url = frame.url();
          if (url.includes("challenges.cloudflare.com")) {
            frameDetachedAt = Date.now();
            const elapsed = mainFrameLoadAt
              ? Math.floor((frameDetachedAt - mainFrameLoadAt) / 1000)
              : "?";
            console.log(`[ts-frame] detached — challenge selesai (${elapsed}s dari load)`);
          }
        } catch {}
      };

      page.on("message", onMessage);
      page.on("framedetached", onFrameDetached);

      try {
        // ── UA ──────────────────────────────────
        try {
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
          );
        } catch {}

        // ── Inject hook postMessage ─────────────
        await page.evaluateOnNewDocument(() => {
          const origPost = window.postMessage.bind(window);
          window.postMessage = function (message, targetOrigin, transfer) {
            try {
              const str = typeof message === "string" ? message : JSON.stringify(message);
              if (str && str.length > 50) {
                const m = str.match(/0\.[A-Za-z0-9_\-]{50,}/);
                if (m) window.__cfTokenHooked = m[0];
              }
            } catch {}
            return origPost(message, targetOrigin, transfer);
          };

          // Hook turnstile.render kalau ada
          Object.defineProperty(window, "turnstile", {
            configurable: true,
            set: function (val) {
              if (val && typeof val.render === "function") {
                const orig = val.render;
                val.render = function (el, opts) {
                  if (opts && typeof opts.callback === "function") {
                    const cb = opts.callback;
                    opts.callback = function (token) {
                      window.__cfTokenCallback = token;
                      return cb(token);
                    };
                  }
                  return orig.call(this, el, opts);
                };
              }
              Object.defineProperty(window, "turnstile", {
                value: val,
                writable: true,
                configurable: true,
              });
            },
            get: function () {
              return undefined;
            },
          });
        });

        // ── Proxy auth ──────────────────────────
        if (proxy && proxy.username && proxy.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        // ── Navigate ────────────────────────────
        console.log(`[ts] navigate to ${origin}/`);
        await page.goto(origin + "/", {
          waitUntil: "domcontentloaded",
          timeout: 45000,
        });
        mainFrameLoadAt = Date.now();

        // ── Fase 1: Bot Management ──────────────
        try {
          await page.waitForFunction(
            () => {
              const t = (document.title || "").toLowerCase();
              return !t.includes("just a moment") &&
                     !t.includes("checking your browser") &&
                     !t.includes("attention required");
            },
            { timeout: 25000, polling: 500 }
          );
          const title = await page.title();
          console.log(`[ts] page loaded: "${title.slice(0, 60)}"`);
        } catch {
          console.log(`[ts] WARN: bot challenge stuck > 25s`);
        }

        // ── Fase 2: Widget ada? ────────────────
        try {
          await page.waitForSelector(
            ".cf-turnstile, iframe[src*='challenges.cloudflare.com']",
            { timeout: 15000, visible: true }
          );
          console.log(`[ts] widget detected`);
        } catch {
          throw new Error("Turnstile widget not found on page");
        }

        // ══════════════════════════════════════════════
        // Fase 3: Loop — cek token tiap 1 detik
        // ══════════════════════════════════════════════
        console.log(`[ts] monitoring token (max ${Math.floor(totalTimeout/1000)}s)`);

        const startTime = Date.now();
        let lastState = null;

        while ((Date.now() - startTime) < totalTimeout) {
          // Cek token dari semua sumber
          const token = await collectToken(page, capturedToken);
          if (token) {
            capturedToken = token;
            break;
          }

          // Update state log
          const state = await checkIframeState(page);
          if (state && state.key !== lastState) {
            lastState = state.key;
            console.log(`[ts-iframe] ${state.detail}`);
          }

          // Kalau frame detached 4+ detik dan tidak ada token → silent reject
          if (frameDetachedAt && (Date.now() - frameDetachedAt) > 4000) {
            const late = await collectToken(page, capturedToken);
            if (late) {
              capturedToken = late;
              break;
            }

            // Fix final: cek hidden input sekali lagi di parent
            const inParent = await page.evaluate(() => {
              const el = document.querySelector('input[name="cf-turnstile-response"]');
              return el && el.value ? el.value : null;
            }).catch(() => null);

            if (inParent && inParent.length >= 10) {
              capturedToken = inParent;
              break;
            }

            // Gagal total — diagnose
            const diag = await diagnoseFailure(page, {
              frameDetachedAt,
              mainFrameLoadAt,
            });
            console.log(`[ts] ❌ CLOUDFLARE_SILENT_REJECT`);
            console.log(`[ts]    ${diag.reason}`);
            console.log(`[ts]    duration: ${diag.duration}s dari page load`);
            console.log(`[ts]    → IP proxy kemungkinan di-flag Cloudflare`);
            console.log(`[ts]    → Solusi: ganti ke residential proxy`);
            throw new Error("Cloudflare silent-reject — IP diblokir");
          }

          await sleep(1000);
        }

        try { page.off("message", onMessage); } catch {}
        try { page.off("framedetached", onFrameDetached); } catch {}

        isResolved = true;
        clearTimeout(cl);

        if (!capturedToken || capturedToken.length < 10) {
          return reject(new Error("Failed to get token"));
        }

        console.log(`[ts] ✅ token OK (${capturedToken.length} chars)`);
        resolve({ token: capturedToken, type: "turnstile" });

      } catch (e) {
        try { page.off("message", onMessage); } catch {}
        try { page.off("framedetached", onFrameDetached); } catch {}
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

// ============================================================
// collectToken — cek 5 sumber
// ============================================================
async function collectToken(page, alreadyCaptured) {
  if (alreadyCaptured && alreadyCaptured.length >= 10) return alreadyCaptured;

  try {
    const result = await page.evaluate(() => {
      // Sumber 1: callback
      if (window.__cfTokenCallback && window.__cfTokenCallback.length >= 10)
        return window.__cfTokenCallback;

      // Sumber 2: postMessage hook
      if (window.__cfTokenHooked && window.__cfTokenHooked.length >= 10)
        return window.__cfTokenHooked;

      // Sumber 3: hidden input
      const el = document.querySelector(
        'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
      );
      if (el && el.value && el.value.length >= 10) return el.value;

      // Sumber 4: turnstile.getResponse()
      try {
        if (window.turnstile && typeof window.turnstile.getResponse === "function") {
          for (let i = 0; i < 10; i++) {
            try {
              const r = window.turnstile.getResponse(i);
              if (r && r.length >= 10) return r;
            } catch {}
          }
        }
      } catch {}

      // Sumber 5: semua input hidden dengan prefix token
      for (const inp of document.querySelectorAll('input[type="hidden"]')) {
        if (inp.value && /^0\.[A-Za-z0-9_\-]{20,}/.test(inp.value)) {
          return inp.value;
        }
      }

      return null;
    });

    return result || null;
  } catch {
    return null;
  }
}

// ============================================================
// checkIframeState — log state iframe
// ============================================================
async function checkIframeState(page) {
  try {
    const frames = page.frames();
    const f = frames.find(x =>
      x.url().includes("challenges.cloudflare.com") &&
      (x.url().includes("turnstile") || x.url().includes("challenge-platform"))
    );
    if (!f) return { key: "no-frame", detail: "frame belum ada" };

    const info = await f.evaluate(() => {
      const text = (document.body?.innerText || "").trim().replace(/\s+/g, " ");
      const lower = text.toLowerCase();
      const hasCheckbox = !!document.querySelector(
        'input[type="checkbox"], [role="checkbox"], .ctp-checkbox-label'
      );
      const hasChallenge = !!document.querySelector('img[src*="challenge"]');
      const hasSpinner = !!document.querySelector('.spinner, [class*="loading"]');
      const hasSuccess = /success|berhasil|verified/i.test(text);

      let errorCode = null;
      if (lower.includes("invalid sitekey")) errorCode = "invalid-sitekey";
      else if (lower.includes("invalid domain")) errorCode = "invalid-domain";

      return { text: text.slice(0, 60), hasCheckbox, hasChallenge, hasSpinner, hasSuccess, errorCode };
    });

    let key, detail;
    if (info.errorCode) {
      key = `error:${info.errorCode}`;
      detail = `state=${key} text="${info.text}"`;
    } else if (info.hasSuccess) {
      key = "success";
      detail = `state=success`;
    } else if (info.hasChallenge) {
      key = "challenge";
      detail = `state=challenge-image (IP dianggap bot!)`;
    } else if (info.hasCheckbox) {
      key = "checkbox";
      detail = `state=checkbox text="${info.text}"`;
    } else if (info.hasSpinner) {
      key = "spinner";
      detail = `state=spinner text="${info.text}"`;
    } else {
      key = "idle";
      detail = `state=idle text="${info.text}"`;
    }

    return { key, detail };
  } catch {
    return null;
  }
}

// ============================================================
// diagnoseFailure — log detail saat silent reject
// ============================================================
async function diagnoseFailure(page, meta) {
  const duration = meta.mainFrameLoadAt && meta.frameDetachedAt
    ? Math.floor((meta.frameDetachedAt - meta.mainFrameLoadAt) / 1000)
    : "?";

  let reason = "Cloudflare tidak keluarkan token meski challenge selesai";
  try {
    const info = await page.evaluate(() => {
      const body = document.body?.innerText || "";
      return {
        title: document.title,
        hasForm: !!document.querySelector('form'),
        hasTurnstileDiv: !!document.querySelector('.cf-turnstile'),
        hasHiddenInput: !!document.querySelector('input[name="cf-turnstile-response"]'),
      };
    });
    if (info.hasHiddenInput && !info.hasForm) {
      reason = "Form hilang setelah challenge — kemungkinan Cloudflare block request submit";
    }
  } catch {}

  return { reason, duration };
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = turnstile;
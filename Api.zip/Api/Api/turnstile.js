
async function turnstile({ domain, siteKey, action, cdata, proxy }, page) {

    if (!domain)
        throw new Error("Missing domain");

    if (!siteKey)
        throw new Error("Missing siteKey");

    if (proxy?.username) {
        await page.authenticate({
            username: proxy.username,
            password: proxy.password
        });
    }

    const html = `
<!DOCTYPE html>
<html>
<body>

<div id="cf"></div>

<script>
window.token = "";

function onloadTurnstileCallback(){

turnstile.render("#cf",{

sitekey:"${siteKey}",

action:"${action||""}",

cData:"${cdata||""}",

callback:function(token){

let input=document.createElement("input");

input.name="cf-response";

input.value=token;

document.body.appendChild(input);

}

});

}

</script>

<script
src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onloadTurnstileCallback"
async defer></script>

</body>
</html>
`;

    page.removeAllListeners("request");

    page.on("request", request => {

        if (
            request.isNavigationRequest() &&
            request.frame() === page.mainFrame()
        ) {

            return request.respond({

                status:200,

                contentType:"text/html",

                body:html

            });

        }

        request.continue();

    });

    await page.goto(domain,{
        waitUntil:"domcontentloaded",
        timeout:global.timeOut
    });

    await page.waitForSelector(
        '[name="cf-response"]',
        {
            timeout:global.timeOut
        }
    );

    const token = await page.$eval(
        '[name="cf-response"]',
        el=>el.value
    );

    return {
        token,
        type:"turnstile"
    };

}
module.exports = turnstile;
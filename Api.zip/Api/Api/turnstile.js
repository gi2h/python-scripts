/**
 * turnstile.js — v10 FALLBACK-INJECT
 * 
 * Strategi:
 *   1. Load halaman asli (pertahankan cookies/session)
 *   2. Tunggu widget auto-render 12 detik
 *   3. Kalau widget TIDAK muncul → inject sendiri:
 *      a. Buat div .cf-turnstile kalau tidak ada
 *      b. Download api.js manual via fetch (wget-style)
 *      c. Panggil turnstile.render() manual
 *   4. Tunggu token dari semua sumber (postMessage/callback/input/getResponse)
 */

"use strict";

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");

  let baseUrl = domain;
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = "https://" + baseUrl;
  const origin = new URL(baseUrl).origin;

  const totalTimeout = global.timeOut || 120000;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    let capturedToken = null;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, totalTimeout + 5000);

    (async () => {
      // ── Listeners ───────────────────────────────
      const onMessage = (msg) => {
        try {
          const text = typeof msg === "string" ? msg : JSON.stringify(msg);
          if (!text) return;
          const m = text.match(/0\.[A-Za-z0-9_\-]{100,}/);
          if (m && !capturedToken) {
            capturedToken = m[0];
            console.log(`[ts-msg] 🎯 token via postMessage (${capturedToken.length} chars)`);
          }
        } catch {}
      };
      page.on("message", onMessage);

      try {
        // ── UA ─────────────────────────────────
        try {
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
          );
        } catch {}

        // ── Pre-inject hook postMessage + fetch helper ────
        await page.evaluateOnNewDocument(() => {
          const origPost = window.postMessage.bind(window);
          window.postMessage = function (message, targetOrigin, transfer) {
            try {
              const str = typeof message === "string" ? message : JSON.stringify(message);
              if (str && str.length > 50) {
                const m = str.match(/0\.[A-Za-z0-9_\-]{50,}/);
                if (m) window.__cfTokenHooked = m[0];
              }
            } catch {}
            return origPost(message, targetOrigin, transfer);
          };
        });

        // ── Proxy auth ──────────────────────────
        if (proxy && proxy.username && proxy.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        // ── Navigate ────────────────────────────
        console.log(`[ts] navigate to ${origin}/`);
        await page.goto(origin + "/", {
          waitUntil: "domcontentloaded",
          timeout: 45000,
        });

        // ── Fase 1: Bot Management ──────────────
        try {
          await page.waitForFunction(
            () => {
              const t = (document.title || "").toLowerCase();
              return !t.includes("just a moment") &&
                     !t.includes("checking your browser") &&
                     !t.includes("attention required");
            },
            { timeout: 25000, polling: 500 }
          );
          const title = await page.title();
          console.log(`[ts] page loaded: "${title.slice(0, 60)}"`);
        } catch {
          console.log(`[ts] WARN: bot challenge stuck > 25s`);
        }

        // ═══════════════════════════════════════════════════
        // FASE 2: Cek widget auto-render (12 detik)
        // ═══════════════════════════════════════════════════
        console.log(`[ts] cek widget auto-render (12s)...`);

        let widgetFound = false;
        try {
          await page.waitForSelector(
            ".cf-turnstile iframe, iframe[src*='challenges.cloudflare.com']",
            { timeout: 12000, visible: true }
          );
          widgetFound = true;
          console.log(`[ts] ✅ widget auto-render OK`);
        } catch {
          console.log(`[ts] ⚠️ widget auto-render GAGAL dalam 12s — coba inject manual`);
        }

        // ═══════════════════════════════════════════════════
        // FASE 3: FALLBACK INJECT (kalau widget tidak render)
        // ═══════════════════════════════════════════════════
        if (!widgetFound) {
          // Ambil sitekey dari HTML (kalau tidak dikirim)
          let effectiveSiteKey = siteKey;
          if (!effectiveSiteKey) {
            effectiveSiteKey = await page.evaluate(() => {
              const d = document.querySelector(".cf-turnstile");
              return d ? d.getAttribute("data-sitekey") : null;
            }).catch(() => null);
          }

          if (!effectiveSiteKey) {
            console.log(`[ts] ❌ tidak ada sitekey — tidak bisa inject`);
            throw new Error("No sitekey available for injection");
          }

          console.log(`[ts] inject widget manual (sitekey=${effectiveSiteKey.slice(0, 20)}...)`);

          const injectResult = await injectTurnstileWidget(
            page, effectiveSiteKey, action || ""
          );
          console.log(`[ts] inject result: ${injectResult}`);

          if (injectResult !== "rendered" && injectResult !== "already-rendered") {
            throw new Error(`Inject gagal: ${injectResult}`);
          }

          // Tunggu iframe baru muncul setelah render
          try {
            await page.waitForSelector(
              "iframe[src*='challenges.cloudflare.com']",
              { timeout: 10000, visible: true }
            );
            console.log(`[ts] ✅ widget inject terdeteksi`);
          } catch {
            console.log(`[ts] ⚠️ iframe tidak muncul setelah inject — lanjut coba tunggu token`);
          }
        }

        // ═══════════════════════════════════════════════════
        // FASE 4: Tunggu token dari semua sumber
        // ═══════════════════════════════════════════════════
        console.log(`[ts] monitoring token (max ${Math.floor(totalTimeout/1000)}s)`);

        const startTime = Date.now();
        let lastState = null;

        while ((Date.now() - startTime) < totalTimeout) {
          // Cek token
          const token = await collectToken(page, capturedToken);
          if (token) {
            capturedToken = token;
            break;
          }

          // Cek state iframe untuk log
          const state = await checkIframeState(page);
          if (state && state.key !== lastState) {
            lastState = state.key;
            console.log(`[ts-iframe] ${state.detail}`);
          }

          await sleep(1000);
        }

        try { page.off("message", onMessage); } catch {}

        isResolved = true;
        clearTimeout(cl);

        if (!capturedToken || capturedToken.length < 10) {
          console.log(`[ts] ❌ tidak ada token dari semua sumber`);
          return reject(new Error("Failed to get token"));
        }

        console.log(`[ts] ✅ token OK (${capturedToken.length} chars)`);
        resolve({ token: capturedToken, type: "turnstile" });

      } catch (e) {
        console.log(`[ts] error: ${e.message}`);
        try { page.off("message", onMessage); } catch {}
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

// ============================================================
// injectTurnstileWidget — Fallback inject
// ============================================================
async function injectTurnstileWidget(page, siteKey, action) {
  try {
    const result = await page.evaluate(async (sk, act) => {
      const log = [];

      // ── Step 1: Pastikan div .cf-turnstile ada ────────
      let div = document.querySelector(".cf-turnstile");
      if (!div) {
        div = document.createElement("div");
        div.className = "cf-turnstile";
        div.setAttribute("data-sitekey", sk);
        div.style.display = "flex";
        div.style.justifyContent = "center";
        div.style.margin = "12px 0";

        const form = document.querySelector("form");
        if (form) {
          const btn = form.querySelector('button[type="submit"]');
          if (btn) form.insertBefore(div, btn);
          else form.appendChild(div);
        } else {
          document.body.appendChild(div);
        }
        log.push("div dibuat");
      } else {
        log.push("div sudah ada");
      }

      // ── Step 2: Kalau turnstile API belum ada, download manual ──
      if (!window.turnstile || typeof window.turnstile.render !== "function") {
        log.push("turnstile API belum ada — download manual");

        // Coba pakai script yang sudah ada dulu
        const existing = document.querySelector('script[src*="challenges.cloudflare.com/turnstile"]');

        await new Promise((resolve) => {
          let done = false;
          const finish = (reason) => {
            if (done) return;
            done = true;
            log.push("script: " + reason);
            resolve();
          };

          // Polling window.turnstile
          const poll = setInterval(() => {
            if (window.turnstile && typeof window.turnstile.render === "function") {
              clearInterval(poll);
              finish("loaded (dari existing)");
            }
          }, 300);
          setTimeout(() => { clearInterval(poll); }, 12000);

          if (existing) {
            // Existing script ada tapi API belum ready — tunggu saja
            setTimeout(() => finish("timeout existing"), 11000);
            return;
          }

          // Download script baru — fetch dulu (wget-style), lalu eval
          (async () => {
            try {
              const url = "https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=__tsCb";
              const resp = await fetch(url, { cache: "force-cache" });
              if (!resp.ok) {
                finish(`fetch status ${resp.status}`);
                return;
              }
              const code = await resp.text();
              log.push(`api.js downloaded (${code.length} bytes)`);

              // Eksekusi via script tag supaya window.turnstile ke-set
              window.__tsCb = () => {
                log.push("onload callback");
                finish("injected via fetch+tag");
              };
              const s = document.createElement("script");
              s.src = url;
              s.async = true;
              s.onerror = () => finish("script tag error");
              document.head.appendChild(s);
              setTimeout(() => finish("timeout after tag"), 11000);
            } catch (e) {
              finish("fetch error: " + e.message);
            }
          })();
        });
      } else {
        log.push("turnstile API sudah ready");
      }

      // ── Step 3: Render widget ─────────────────────────
      if (!window.turnstile || typeof window.turnstile.render !== "function") {
        return "api-not-available: " + log.join(" | ");
      }

      // Cek apakah div ini sudah pernah dirender
      const alreadyRendered = div.getAttribute("data-rendered");
      if (alreadyRendered === "1") {
        return "already-rendered: " + log.join(" | ");
      }

      try {
        div.setAttribute("data-rendered", "1");
        window.turnstile.render(div, {
          sitekey: sk,
          action: act || "",
          callback: (t) => {
            window.__cfTokenCallback = t;
          },
          "error-callback": (code) => {
            window.__cfError = code;
          },
        });
        log.push("render dipanggil");
      } catch (e) {
        return "render-error: " + e.message + " | " + log.join(" | ");
      }

      return "rendered: " + log.join(" | ");
    }, siteKey, action);

    // Log detail step
    if (result && result.includes("|")) {
      const parts = result.split("|").map(s => s.trim());
      for (const p of parts) {
        console.log(`[ts-inject]   ${p}`);
      }
    }

    if (result && result.startsWith("rendered")) return "rendered";
    if (result && result.startsWith("already-rendered")) return "already-rendered";
    return result || "unknown";
  } catch (e) {
    return "exception: " + e.message;
  }
}

// ============================================================
// collectToken — 5 sumber
// ============================================================
async function collectToken(page, alreadyCaptured) {
  if (alreadyCaptured && alreadyCaptured.length >= 10) return alreadyCaptured;

  try {
    const result = await page.evaluate(() => {
      // 1. callback
      if (window.__cfTokenCallback && window.__cfTokenCallback.length >= 10)
        return window.__cfTokenCallback;

      // 2. postMessage hook
      if (window.__cfTokenHooked && window.__cfTokenHooked.length >= 10)
        return window.__cfTokenHooked;

      // 3. hidden input
      const el = document.querySelector(
        'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
      );
      if (el && el.value && el.value.length >= 10) return el.value;

      // 4. turnstile.getResponse()
      try {
        if (window.turnstile && typeof window.turnstile.getResponse === "function") {
          for (let i = 0; i < 10; i++) {
            try {
              const r = window.turnstile.getResponse(i);
              if (r && r.length >= 10) return r;
            } catch {}
          }
        }
      } catch {}

      // 5. semua hidden input dengan prefix token
      for (const inp of document.querySelectorAll('input[type="hidden"]')) {
        if (inp.value && /^0\.[A-Za-z0-9_\-]{20,}/.test(inp.value)) {
          return inp.value;
        }
      }

      return null;
    });

    return result || null;
  } catch {
    return null;
  }
}

// ============================================================
// checkIframeState
// ============================================================
async function checkIframeState(page) {
  try {
    const frames = page.frames();
    const f = frames.find(x =>
      x.url().includes("challenges.cloudflare.com") &&
      (x.url().includes("turnstile") || x.url().includes("challenge-platform"))
    );
    if (!f) return { key: "no-frame", detail: "state=no-iframe-yet" };

    const info = await f.evaluate(() => {
      const text = (document.body?.innerText || "").trim().replace(/\s+/g, " ");
      const lower = text.toLowerCase();
      const hasCheckbox = !!document.querySelector(
        'input[type="checkbox"], [role="checkbox"], .ctp-checkbox-label'
      );
      const hasChallenge = !!document.querySelector('img[src*="challenge"]');
      const hasSpinner = !!document.querySelector('.spinner, [class*="loading"]');
      const hasSuccess = /success|berhasil|verified/i.test(text);

      let errorCode = null;
      if (lower.includes("invalid sitekey")) errorCode = "invalid-sitekey";
      else if (lower.includes("invalid domain")) errorCode = "invalid-domain";

      return { text: text.slice(0, 60), hasCheckbox, hasChallenge, hasSpinner, hasSuccess, errorCode };
    });

    let key, detail;
    if (info.errorCode) {
      key = `error:${info.errorCode}`;
      detail = `state=${key} text="${info.text}"`;
    } else if (info.hasSuccess) {
      key = "success";
      detail = `state=success`;
    } else if (info.hasChallenge) {
      key = "challenge";
      detail = `state=challenge-image (IP dianggap bot)`;
    } else if (info.hasCheckbox) {
      key = "checkbox";
      detail = `state=checkbox text="${info.text}"`;
    } else if (info.hasSpinner) {
      key = "spinner";
      detail = `state=spinner text="${info.text}"`;
    } else {
      key = "idle";
      detail = `state=idle text="${info.text}"`;
    }

    return { key, detail };
  } catch {
    return null;
  }
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

module.exports = turnstile;
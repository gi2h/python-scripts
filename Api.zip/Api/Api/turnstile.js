/**
 * turnstile.js — Robust Turnstile Solver
 * Fixed: preserve stealth listeners + full HTML + anti-detect patch
 */

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 60000;
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    let requestHandler = null;

    try {
      // ── Proxy auth ──────────────────────────────────────
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      // ── Viewport realistis ──────────────────────────────
      try {
        await page.setViewport({
          width: 1366,
          height: 768,
          deviceScaleFactor: 1,
        });
      } catch (e) {
        console.log(`${TAG} setViewport warning: ${e.message}`);
      }

      // ── HTML halaman host ───────────────────────────────
      const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Just a moment...</title>
</head>
<body style="margin:0;padding:0;background:#ffffff;font-family:Arial,sans-serif;">
  <div class="cf-turnstile" style="margin:20px;"></div>
  <script>
    (function() {
      // ── Anti-detection patch ──
      try {
        Object.defineProperty(navigator, 'webdriver', {
          get: () => undefined,
          configurable: true
        });
      } catch (e) {}

      try {
        Object.defineProperty(navigator, 'plugins', {
          get: () => [
            { name: 'PDF Viewer', filename: 'internal-pdf-viewer' },
            { name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer' },
            { name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer' },
            { name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer' },
            { name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer' }
          ],
          configurable: true
        });
      } catch (e) {}

      try {
        Object.defineProperty(navigator, 'languages', {
          get: () => ['en-US', 'en'],
          configurable: true
        });
      } catch (e) {}

      try {
        Object.defineProperty(navigator, 'hardwareConcurrency', {
          get: () => 8,
          configurable: true
        });
      } catch (e) {}

      try {
        Object.defineProperty(navigator, 'deviceMemory', {
          get: () => 8,
          configurable: true
        });
      } catch (e) {}

      try {
        if (!window.chrome) {
          window.chrome = {
            runtime: {},
            loadTimes: function() {},
            csi: function() {},
            app: {}
          };
        }
      } catch (e) {}

      try {
        const origQuery = window.navigator.permissions && window.navigator.permissions.query;
        if (origQuery) {
          window.navigator.permissions.query = function(parameters) {
            if (parameters.name === 'notifications') {
              return Promise.resolve({ state: Notification.permission });
            }
            return origQuery(parameters);
          };
        }
      } catch (e) {}
    })();

    // ── Global state ──
    window.__ts_token   = null;
    window.__ts_error   = null;
    window.__ts_timeout = false;

    window.onloadTurnstileCallback = function() {
      try {
        turnstile.render('.cf-turnstile', {
          sitekey: '${siteKey}',
          action: ${JSON.stringify(action || "")},
          theme: 'light',
          callback: function(token) {
            window.__ts_token = token;
            console.log('[ts] token received, len=' + token.length);
          },
          'error-callback': function(e) {
            window.__ts_error = e || 'unknown';
            console.log('[ts] error-callback: ' + e);
          },
          'timeout-callback': function() {
            window.__ts_timeout = true;
            console.log('[ts] timeout-callback fired');
          },
          'expired-callback': function() {
            window.__ts_token = null;
            console.log('[ts] expired-callback');
          }
        });
      } catch (e) {
        window.__ts_error = 'render-exception: ' + e.message;
        console.log('[ts] render exception: ' + e.message);
      }
    };
  </script>
  <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onloadTurnstileCallback" defer></script>
</body>
</html>`;

      // ── Interception ────────────────────────────────────
      console.log(`${TAG} enabling request interception`);
      await page.setRequestInterception(true);

      // ⚠️ JANGAN removeAllListeners — puppeteer-real-browser
      // pasang listener stealth yang harus dipertahankan.

      requestHandler = async (request) => {
        try {
          const url = request.url();
          const normalizedDomain = domain.replace(/\/$/, "");
          const isTargetDoc = (
            url === domain ||
            url === domain + "/" ||
            url === normalizedDomain ||
            url === normalizedDomain + "/"
          ) && request.resourceType() === "document";

          if (isTargetDoc) {
            console.log(`${TAG} intercepting: ${url}`);
            await request.respond({
              status: 200,
              contentType: "text/html; charset=utf-8",
              headers: {
                "cache-control": "no-cache, no-store, must-revalidate",
                "content-type": "text/html; charset=utf-8"
              },
              body: htmlContent,
            });
          } else {
            await request.continue();
          }
        } catch (e) {
          // Request mungkin sudah handled / aborted
          try { await request.continue(); } catch (_) {}
        }
      };

      page.on("request", requestHandler);

      // ── Goto ────────────────────────────────────────────
      console.log(`${TAG} goto ${domain}`);
      await page.goto(domain, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      // ── Tunggu token ────────────────────────────────────
      console.log(`${TAG} waiting for token...`);
      const tokenHandle = await page.waitForFunction(
        () => {
          if (window.__ts_token && window.__ts_token.length >= 10) {
            return window.__ts_token;
          }
          const el = document.querySelector(
            '.cf-turnstile input[name="cf-turnstile-response"], input[name="cf-turnstile-response"]'
          );
          if (el && el.value && el.value.length >= 10) {
            return el.value;
          }
          if (window.__ts_error) {
            throw new Error("Turnstile error: " + window.__ts_error);
          }
          if (window.__ts_timeout) {
            throw new Error("Turnstile timeout");
          }
          return false;
        },
        { timeout, polling: 300 }
      );

      const token = await tokenHandle.jsonValue();

      // ── Cleanup handler spesifik kita ───────────────────
      try { page.off("request", requestHandler); } catch (_) {}
      requestHandler = null;

      isResolved = true;
      clearTimeout(cl);

      if (!token || token.length < 10) {
        reject(new Error("Failed to get token (len=" +
          (token ? token.length : 0) + ")"));
      } else {
        console.log(`${TAG} ✅ solved, token len=${token.length}`);
        resolve({ token, type: "turnstile" });
      }

    } catch (e) {
      console.log(`${TAG} ❌ EXCEPTION`);
      console.log(`${TAG}   name    : ${e?.name || "(none)"}`);
      console.log(`${TAG}   message : ${e?.message || "(none)"}`);
      console.log(`${TAG}   stack   :`);
      console.log(e?.stack || "(no stack)");

      try { page.off("request", requestHandler); } catch (_) {}

      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
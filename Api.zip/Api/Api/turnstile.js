/**
 * turnstile.js — v14.0 (Minimal HTML Inject + Checkbox Clicker + Token Extractor)
 * Mengadopsi teknik dari Theyka/Turnstile-Solver dan VoidCrawl.
 */
"use strict";

// Template HTML Minimalis untuk Inject Turnstile
const MINIMAL_HTML = (sitekey) => `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Verification</title>
    <style>
        body { padding: 50px; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; }
        #cf-container { margin: 20px 0; }
        #status { font-size: 14px; color: #333; }
    </style>
</head>
<body>
    <h2>Security Check</h2>
    <div id="cf-container" class="cf-turnstile"></div>
    <div id="status">Waiting for Turnstile...</div>
    <script>
        window.__cfToken = null;
        window.__cfError = null;
        window.__cfLoaded = false;

        window.onloadCallback = function() {
            window.__cfLoaded = true;
            document.getElementById('status').textContent = 'Rendering widget...';
            try {
                window.turnstile.render('#cf-container', {
                    sitekey: '${sitekey}',
                    callback: function(token) {
                        window.__cfToken = token;
                        document.getElementById('status').textContent = 'Success!';
                        // Simpan token ke input hidden agar mudah diekstrak
                        let input = document.querySelector('input[name="cf-turnstile-response"]');
                        if (!input) {
                            input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'cf-turnstile-response';
                            document.body.appendChild(input);
                        }
                        input.value = token;
                    },
                    'error-callback': function(code) {
                        window.__cfError = code;
                        document.getElementById('status').textContent = 'Error: ' + code;
                    }
                });
            } catch (e) {
                document.getElementById('status').textContent = 'Render Error: ' + e.message;
            }
        };
    </script>
    <!-- Load script Cloudflare secara eksplisit -->
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onloadCallback" async defer></script>
</body>
</html>`;

async function turnstile({ domain, siteKey, proxy }, page) {
    if (!domain) throw new Error("Missing domain parameter");
    if (!siteKey) throw new Error("Missing siteKey parameter");

    let targetUrl = domain;
    if (!/^https?:\/\//i.test(targetUrl)) targetUrl = "https://" + targetUrl;
    // Pastikan kita mengunjungi root atau halaman claim yang valid
    const origin = new URL(targetUrl).origin;

    const totalTimeout = global.timeOut || 120000;

    return new Promise((resolve, reject) => {
        let isResolved = false;
        let capturedToken = null;

        const timeoutTimer = setTimeout(() => {
            if (!isResolved) {
                isResolved = true;
                reject(new Error("Timeout Error"));
            }
        }, totalTimeout + 5000);

        (async () => {
            // Listener untuk menangkap token dari postMessage (jika ada)
            const onMessage = (msg) => {
                try {
                    const text = typeof msg === "string" ? msg : JSON.stringify(msg);
                    if (!text) return;
                    const m = text.match(/[01]\.[A-Za-z0-9_\-]{100,}/);
                    if (m && !capturedToken) {
                        capturedToken = m[0];
                        console.log(`[ts-msg] 🎯 Token ditemukan via postMessage (${capturedToken.length} chars)`);
                    }
                } catch {}
            };
            page.on("message", onMessage);

            try {
                // 1. PROXY AUTH
                if (proxy && proxy.username && proxy.password) {
                    await page.authenticate({
                        username: proxy.username,
                        password: proxy.password,
                    });
                    console.log(`[ts] Proxy auth set: ${proxy.username.slice(0, 15)}...`);
                }

                // 2. INTERCEPT & INJECT HTML
                console.log(`[ts] Mengaktifkan intercept untuk ${origin}...`);
                await page.setRequestInterception(true);
                const requestHandler = (req) => {
                    // Cegat semua request dokumen (HTML) utama
                    if (req.resourceType() === "document") {
                        console.log(`[ts] Injecting minimal HTML ke: ${req.url()}`);
                        req.respond({
                            status: 200,
                            contentType: "text/html; charset=utf-8",
                            body: MINIMAL_HTML(siteKey),
                        });
                    } else {
                        req.continue();
                    }
                };
                page.on("request", requestHandler);

                console.log(`[ts] Navigasi ke: ${origin}`);
                await page.goto(origin, { waitUntil: "domcontentloaded", timeout: 45000 });

                // 3. TUNGGU RENDER & DETEKSI CHECKBOX
                console.log(`[ts] Menunggu widget dimuat...`);
                await page.waitForSelector('iframe[src*="challenges.cloudflare.com"]', { timeout: 15000 }).catch(() => {
                    console.log(`[ts] ⚠️ Timeout menunggu iframe.`);
                });

                const startTime = Date.now();
                let lastState = "";

                while (Date.now() - startTime < totalTimeout) {
                    if (capturedToken) break;

                    // Cek token langsung dari DOM
                    const tok = await page.evaluate(() => window.__cfToken || document.querySelector('input[name="cf-turnstile-response"]')?.value).catch(() => null);
                    if (tok) {
                        capturedToken = tok;
                        break;
                    }

                    // Cek apakah ada checkbox dan klik jika perlu
                    const frames = page.frames();
                    const cfFrame = frames.find(f => f.url().includes("challenges.cloudflare.com"));
                    
                    if (cfFrame) {
                        // Deteksi status di dalam iframe
                        const frameState = await cfFrame.evaluate(() => {
                            const text = (document.body?.innerText || "").toLowerCase();
                            const hasCheckbox = !!document.querySelector('input[type="checkbox"], [role="checkbox"]');
                            return { text: text.slice(0, 50), hasCheckbox };
                        }).catch(() => ({ text: "", hasCheckbox: false }));

                        if (frameState.hasCheckbox) {
                            console.log(`[ts] 👀 Checkbox terdeteksi! Mencoba klik...`);
                            // Gunakan AX Tree atau koordinat (di sini kita coba klik via frame evaluate sederhana, 
                            // jika gagal, biarkan puppeteer-real-browser yang menangani)
                            await cfFrame.evaluate(() => {
                                const cb = document.querySelector('input[type="checkbox"], [role="checkbox"]');
                                if (cb) cb.click();
                            }).catch(() => {});
                            
                            // Jeda untuk memberi waktu Cloudflare memproses
                            await new Promise(r => setTimeout(r, 3000));
                        }
                    }

                    // Log progress per 5 detik
                    const elapsed = Math.floor((Date.now() - startTime) / 1000);
                    if (elapsed > 0 && elapsed % 5 === 0 && elapsed !== lastState) {
                        lastState = elapsed;
                        console.log(`[ts] ${elapsed}s — Menunggu token...`);
                    }

                    await new Promise(r => setTimeout(r, 1000));
                }

                // Cleanup intercept
                page.off("request", requestHandler);
                await page.setRequestInterception(false).catch(() => {});
                page.off("message", onMessage);

                isResolved = true;
                clearTimeout(timeoutTimer);

                if (!capturedToken || capturedToken.length < 10) {
                    throw new Error("Gagal mendapatkan token setelah timeout.");
                }

                console.log(`[ts] ✅ Token berhasil didapat (${capturedToken.length} chars).`);
                resolve({ token: capturedToken, type: "turnstile" });

            } catch (e) {
                console.log(`[ts] ❌ Error: ${e.message}`);
                if (!isResolved) {
                    isResolved = true;
                    clearTimeout(timeoutTimer);
                    reject(e);
                }
            }
        })();
    });
}

module.exports = turnstile;
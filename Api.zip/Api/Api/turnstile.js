/**
 * turnstile.js v10 — Extract token dari object + trap assignment
 */

async function turnstile({ domain, siteKey, action, proxy, referer }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 150000;
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({ username: proxy.username, password: proxy.password });
      }

      try { await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 }); } catch (e) {}

      await page.setExtraHTTPHeaders({
        "Referer": referer || "https://www.google.com/",
        "Accept-Language": "en-US,en;q=0.9",
      });

      console.log(`${TAG} goto ${domain}/faucet/index.php`);
      await page.goto(`${domain.replace(/\/$/, "")}/faucet/index.php`, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      await new Promise((r) => setTimeout(r, 5000));

      // ── TRAP _turnstileToken assignment ────────────────
      console.log(`${TAG} installing trap on _turnstileToken`);
      await page.evaluate(() => {
        window.__capturedTokens = [];
        let _stored = null;
        try {
          Object.defineProperty(window, "_turnstileToken", {
            configurable: true,
            get: function () { return _stored; },
            set: function (val) {
              console.log("[trap] _turnstileToken set: " + typeof val + " / " +
                          (typeof val === "string" ? val.slice(0, 30) : JSON.stringify(val).slice(0, 200)));
              _stored = val;
              // Coba ekstrak token string
              let tk = null;
              if (typeof val === "string" && val.length >= 20) tk = val;
              else if (val && typeof val === "object") {
                tk = val.token || val.value || val.response || val.turnstileToken || null;
              }
              if (tk && tk.length >= 20) {
                window.__capturedTokens.push(tk);
                console.log("[trap] captured token, len=" + tk.length);
              }
            }
          });
        } catch (e) {
          console.log("[trap] defineProperty err: " + e.message);
        }
      });

      // ── Klik loop ──────────────────────────────────────
      const tryClickCheckbox = async (attemptNum) => {
        const frames = page.frames();
        const cfFrames = frames.filter(f => f.url().includes("challenges.cloudflare.com"));
        console.log(`${TAG} click #${attemptNum}, CF frames: ${cfFrames.length}`);

        for (const frame of cfFrames) {
          try {
            const info = await frame.evaluate(() => {
              const r = { bodyText: "", rect: null };
              const clickable = document.querySelector('input[type="checkbox"], label, [role="button"], .ctp-checkbox-label');
              if (clickable) {
                const bb = clickable.getBoundingClientRect();
                if (bb.width > 0 && bb.height > 0) r.rect = { x: bb.x, y: bb.y, width: bb.width, height: bb.height };
              }
              r.bodyText = (document.body && document.body.innerText || "").slice(0, 150).replace(/\s+/g, " ");
              return r;
            });
            if (info.bodyText) console.log(`${TAG}   body: "${info.bodyText}"`);
            const fe = await frame.frameElement();
            if (fe) {
              const box = await fe.boundingBox();
              if (box) {
                const cx = box.x + 25;
                const cy = box.y + box.height / 2;
                await page.mouse.move(cx - 10, cy - 10);
                await new Promise(r => setTimeout(r, 100));
                await page.mouse.move(cx, cy);
                await new Promise(r => setTimeout(r, 100));
                await page.mouse.click(cx, cy);
              }
            }
          } catch (e) {}
        }
      };

      const getToken = async () => {
        return await page.evaluate(() => {
          // 1. Cek captured tokens dari trap
          if (window.__capturedTokens && window.__capturedTokens.length > 0) {
            return { src: "__capturedTokens", token: window.__capturedTokens[window.__capturedTokens.length - 1] };
          }
          // 2. Cek _turnstileToken dengan berbagai tipe
          const t = window._turnstileToken;
          if (t) {
            if (typeof t === "string" && t.length >= 20) return { src: "_turnstileToken:string", token: t };
            if (typeof t === "object") {
              const cand = t.token || t.value || t.response || t.turnstileToken;
              if (typeof cand === "string" && cand.length >= 20) return { src: "_turnstileToken:object", token: cand };
            }
          }
          // 3. Cek __ts_token
          if (window.__ts_token && typeof window.__ts_token === "string" && window.__ts_token.length >= 20) {
            return { src: "__ts_token", token: window.__ts_token };
          }
          // 4. Cek input
          for (const el of document.querySelectorAll("input, textarea")) {
            const v = el.value || "";
            if (v.length >= 20 && (v.startsWith("0.") || v.startsWith("1.") || el.name?.includes("cf-chl"))) {
              return { src: "input:" + (el.name || el.id), token: v };
            }
          }
          return null;
        });
      };

      console.log(`${TAG} starting click+wait loop`);
      const startTime = Date.now();
      let attempt = 0;

      while (Date.now() - startTime < timeout) {
        attempt++;

        // Cek token
        let t = await getToken();
        if (t) {
          isResolved = true;
          clearTimeout(cl);
          console.log(`${TAG} ✅ token via ${t.src}, len=${t.token.length}`);
          return resolve({ token: t.token, type: "turnstile" });
        }

        await tryClickCheckbox(attempt);
        await new Promise(r => setTimeout(r, 2000));

        t = await getToken();
        if (t) {
          isResolved = true;
          clearTimeout(cl);
          console.log(`${TAG} ✅ token via ${t.src}, len=${t.token.length}`);
          return resolve({ token: t.token, type: "turnstile" });
        }

        // Log detail tiap 3 attempts
        if (attempt % 3 === 0) {
          const detail = await page.evaluate(() => {
            const t = window._turnstileToken;
            let tStr = "null";
            try {
              if (typeof t === "string") tStr = "string(" + t.length + "):" + t.slice(0, 30);
              else if (typeof t === "object" && t !== null) tStr = "object:" + JSON.stringify(t).slice(0, 200);
              else tStr = typeof t;
            } catch (e) { tStr = "err:" + e.message; }
            return {
              tType: typeof t,
              tDetail: tStr,
              captured: window.__capturedTokens ? window.__capturedTokens.length : 0,
            };
          });
          console.log(`${TAG} [${attempt}] _turnstileToken=${detail.tType} detail=${detail.tDetail} captured=${detail.captured}`);
          console.log(`${TAG} [${attempt}] elapsed: ${Math.round((Date.now() - startTime) / 1000)}s`);
        }

        await new Promise(r => setTimeout(r, 1500));
      }

      throw new Error("Click loop timeout");

    } catch (e) {
      console.log(`${TAG} ❌ ${e?.name || "Error"}: ${e?.message || "unknown"}`);
      try {
        const dump = await page.evaluate(() => {
          const t = window._turnstileToken;
          let dump = "null";
          try { dump = typeof t + ":" + JSON.stringify(t).slice(0, 300); } catch (e) { dump = "err"; }
          return {
            turnstileToken: dump,
            captured: window.__capturedTokens || [],
          };
        });
        console.log(`${TAG} final dump: ${JSON.stringify(dump)}`);
      } catch (er) {}
      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
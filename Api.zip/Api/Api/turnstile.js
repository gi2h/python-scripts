/**
 * turnstile.js v5 — Navigate ke halaman asli + full network capture
 * Fix: navigate ke /faucet/index.php, referer valid, log CF responses
 */

async function turnstile({ domain, siteKey, action, proxy, referer }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 120000;   // naik 120s
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      // ── Proxy auth ──────────────────────────────────────
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      // ── Viewport ────────────────────────────────────────
      try {
        await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 });
      } catch (e) {
        console.log(`${TAG} setViewport warning: ${e.message}`);
      }

      // ── Full network capture: fokus ke Cloudflare ──────
      const cfNetLog = [];
      try {
        page.on("response", async (response) => {
          try {
            const url = response.url();
            const status = response.status();
            const isCF = url.includes("challenges.cloudflare.com")
                       || url.includes("cf-challenge")
                       || url.includes("turnstile");
            const isErr = status >= 400;
            if (isCF) {
              console.log(`[net:cf] ${status} ${url.slice(0, 130)}`);
              cfNetLog.push({ status, url, ts: Date.now() });
            } else if (isErr) {
              console.log(`[net:err] ${status} ${url.slice(0, 130)}`);
            }
          } catch {}
        });

        page.on("request", (req) => {
          try {
            const url = req.url();
            if (url.includes("challenges.cloudflare.com")) {
              console.log(`[net:req] ${req.method()} ${url.slice(0, 130)}`);
            }
          } catch {}
        });
      } catch (e) {
        console.log(`${TAG} net listener error: ${e.message}`);
      }

      // ── WebGL check ─────────────────────────────────────
      try {
        const webglInfo = await page.evaluate(() => {
          const c = document.createElement("canvas");
          const gl = c.getContext("webgl") || c.getContext("experimental-webgl");
          if (!gl) return { ok: false };
          const dbg = gl.getExtension("WEBGL_debug_renderer_info");
          return {
            ok: true,
            renderer: dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : "n/a",
          };
        });
        console.log(`${TAG} WebGL: ok=${webglInfo.ok}`);
      } catch {}

      // ── Coba navigasi ke 3 URL alternatif ───────────────
      const targets = [
        `${domain.replace(/\/$/, "")}/faucet/index.php`,
        `${domain.replace(/\/$/, "")}/faucet/`,
        domain,
      ];

      const refererHeader = referer || "https://www.google.com/";
      console.log(`${TAG} Referer: ${refererHeader}`);

      let finalUrl = null;
      let pageTitle = "";
      let pageBodyPreview = "";

      for (const target of targets) {
        console.log(`${TAG} >>> COBA: ${target}`);
        try {
          // Set referer via page.setExtraHTTPHeaders (per-page override)
          await page.setExtraHTTPHeaders({
            "Referer": refererHeader,
            "Accept-Language": "en-US,en;q=0.9",
          });

          const resp = await page.goto(target, {
            waitUntil: "domcontentloaded",
            timeout: Math.min(timeout, 45000),
          });

          // Tunggu sebentar
          await new Promise((r) => setTimeout(r, 4000));

          finalUrl = page.url();
          pageTitle = await page.title().catch(() => "");
          try {
            pageBodyPreview = await page.evaluate(() => {
              return (document.body && document.body.innerText || "")
                .replace(/\s+/g, " ")
                .trim()
                .slice(0, 200);
            });
          } catch {}

          console.log(`${TAG} Response status: ${resp ? resp.status() : "?"}`);
          console.log(`${TAG} Final URL: ${finalUrl}`);
          console.log(`${TAG} Title: ${pageTitle}`);
          console.log(`${TAG} Body: ${pageBodyPreview}`);

          // Cek apakah ini halaman ads / redirect
          const isAdPage = finalUrl && (
            finalUrl.includes("a-ads.com") ||
            finalUrl.includes("bitcotasks") ||
            finalUrl.includes("ads.php") ||
            finalUrl.includes("redirect")
          );

          // Cek native widget
          const hasNativeWidget = await page.evaluate(() => {
            return !!document.querySelector(
              '.cf-turnstile, [data-sitekey], iframe[src*="challenges.cloudflare.com"]'
            );
          });

          console.log(`${TAG} native widget: ${hasNativeWidget}`);

          if (isAdPage) {
            console.log(`${TAG} ⚠ Ter-redirect ke ads, coba URL lain...`);
            continue;
          }

          if (hasNativeWidget || target.includes("faucet")) {
            console.log(`${TAG} ✅ URL ini yang tepat: ${target}`);
            break;
          }
        } catch (e) {
          console.log(`${TAG} goto ${target} gagal: ${e.message}`);
        }
      }

      // ── Kalau native widget ada, langsung tunggu ────────
      const hasNativeNow = await page.evaluate(() => {
        return !!document.querySelector(
          '.cf-turnstile, [data-sitekey], iframe[src*="challenges.cloudflare.com"]'
        );
      });

      if (hasNativeNow) {
        console.log(`${TAG} 🎯 Native widget terdeteksi, tunggu token native...`);
        // Tunggu token di input hidden
        const tokenHandle = await page.waitForFunction(
          () => {
            const el = document.querySelector(
              'input[name="cf-turnstile-response"], .cf-turnstile input[name="cf-turnstile-response"]'
            );
            if (el && el.value && el.value.length >= 10) return el.value;
            return false;
          },
          { timeout, polling: 500 }
        );
        const token = await tokenHandle.jsonValue();
        isResolved = true;
        clearTimeout(cl);
        console.log(`${TAG} ✅ Native token len=${token.length}`);
        return resolve({ token, type: "turnstile" });
      }

      // ── Tidak ada native, inject manual ─────────────────
      console.log(`${TAG} inject manual widget`);
      await page.evaluate((injectedSiteKey, injectedAction) => {
        document.querySelectorAll(".cf-turnstile").forEach((el) => el.remove());
        const div = document.createElement("div");
        div.className = "cf-turnstile";
        div.style.cssText = "position:fixed;top:0;left:0;z-index:99999;background:#fff;padding:10px;";
        document.body.appendChild(div);

        window.__ts_token = null;
        window.__ts_error = null;
        window.__ts_timeout = false;

        function initWidget() {
          try {
            window.turnstile.render(div, {
              sitekey: injectedSiteKey,
              action: injectedAction || "",
              theme: "light",
              callback: (token) => {
                window.__ts_token = token;
                console.log("[ts] token len=" + token.length);
              },
              "error-callback": (e) => {
                window.__ts_error = e || "unknown";
                console.log("[ts] error=" + e);
              },
              "timeout-callback": () => {
                window.__ts_timeout = true;
                console.log("[ts] timeout");
              },
            });
            console.log("[ts] render OK");
          } catch (e) {
            window.__ts_error = "render-exception: " + e.message;
            console.log("[ts] render error: " + e.message);
          }
        }

        if (typeof window.turnstile !== "undefined" && window.turnstile.render) {
          initWidget();
        } else {
          const s = document.createElement("script");
          s.src = "https://challenges.cloudflare.com/turnstile/v0/api.js?onload=__ts_onload";
          s.async = true; s.defer = true;
          window.__ts_onload = initWidget;
          document.head.appendChild(s);
        }
      }, siteKey, action || "");

      // ── Tunggu token ────────────────────────────────────
      console.log(`${TAG} waiting for token...`);
      const tokenHandle = await page.waitForFunction(
        () => {
          if (window.__ts_token && window.__ts_token.length >= 10) return window.__ts_token;
          if (window.__ts_error) throw new Error("Turnstile error: " + window.__ts_error);
          if (window.__ts_timeout) throw new Error("Turnstile timeout");
          return false;
        },
        { timeout, polling: 500 }
      );

      const token = await tokenHandle.jsonValue();
      isResolved = true;
      clearTimeout(cl);

      // ── Log summary network CF ──────────────────────────
      console.log(`${TAG} === CF Network Summary ===`);
      cfNetLog.forEach(x => console.log(`${TAG}   ${x.status} ${x.url.slice(0, 100)}`));

      if (!token || token.length < 10) {
        reject(new Error("Failed to get token"));
      } else {
        console.log(`${TAG} ✅ solved, len=${token.length}`);
        resolve({ token, type: "turnstile" });
      }
    } catch (e) {
      console.log(`${TAG} ❌ ${e?.name || "Error"}: ${e?.message || "unknown"}`);
      console.log(`${TAG} stack: ${(e?.stack || "").slice(0, 500)}`);
      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
/**
 * turnstile.js — v12.1 MINIMAL-HTML-INJECT (Proxy Enhanced)
 */
"use strict";

const MINIMAL_HTML = (sitekey) => `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Verify</title>
<style>body{padding:60px;font-family:system-ui,sans-serif}
#cf-container{display:flex;justify-content:center;margin:30px 0}</style>
</head>
<body>
<h1 style="text-align:center">Turnstile Solver</h1>
<div id="cf-container" class="cf-turnstile"></div>
<script>
  window.__cfToken = null;
  window.__cfError = null;
  window.__cfLoaded = false;
  window.onTsLoad = function() {
    window.__cfLoaded = true;
    try {
      window.turnstile.render('#cf-container', {
        sitekey: '${sitekey}',
        callback: function(token) {
          window.__cfToken = token;
          var inp = document.createElement('input');
          inp.type = 'hidden';
          inp.name = 'cf-turnstile-response';
          inp.value = token;
          document.body.appendChild(inp);
        },
        'error-callback': function(code) {
          window.__cfError = code;
        }
      });
    } catch (e) { window.__cfError = 'render:' + e.message; }
  };
</script>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onTsLoad" async defer></script>
</body>
</html>`;

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");

  let targetUrl = domain;
  if (!/^https?:\/\//i.test(targetUrl)) targetUrl = "https://" + targetUrl;

  const totalTimeout = global.timeOut || 120000;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    let capturedToken = null;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, totalTimeout + 5000);

    (async () => {
      const onMessage = (msg) => {
        try {
          const text = typeof msg === "string" ? msg : JSON.stringify(msg);
          if (!text) return;
          const m = text.match(/[01]\.[A-Za-z0-9_\-]{100,}/);
          if (m && !capturedToken) {
            capturedToken = m[0];
            console.log(`[ts-msg] 🎯 token via postMessage (${capturedToken.length} chars)`);
          }
        } catch {}
      };
      page.on("message", onMessage);

      try {
        // PROXY AUTH (Sangat Penting!)
        if (proxy && proxy.username && proxy.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        // SETUP INTERCEPT
        let intercepted = false;
        const responseHandler = (req) => {
          const url = req.url();
          const type = req.resourceType();

          // Intercept halaman claim
          if (type === "document" && (url.includes("/final-") || url.includes("-claim"))) {
            if (!intercepted) {
              console.log(`[ts] INTERCEPT DOCUMENT → minimal HTML`);
              intercepted = true;
            }
            req.respond({
              status: 200,
              contentType: "text/html; charset=utf-8",
              body: MINIMAL_HTML(siteKey || "0x4AAAAAAFkfYm8hLuheqVuc"),
            });
          } else {
            req.continue();
          }
        };

        await page.setRequestInterception(true);
        page.on("request", responseHandler);

        console.log(`[ts] navigate to ${targetUrl} (intercept mode)`);
        try {
          await page.goto(targetUrl, {
            waitUntil: "domcontentloaded",
            timeout: 30000,
          });
        } catch (e) {
          console.log(`[ts] nav warning: ${e.message}`);
        }

        console.log(`[ts] monitoring token (max ${Math.floor(totalTimeout/1000)}s)`);
        const startTime = Date.now();
        let lastLogTime = 0;

        while ((Date.now() - startTime) < totalTimeout) {
          if (capturedToken) break;

          const tok = await collectToken(page, capturedToken);
          if (tok) {
            capturedToken = tok;
            break;
          }

          const err = await page.evaluate(() => window.__cfError || null).catch(() => null);
          if (err) {
            console.log(`[ts] ❌ widget error: ${err}`);
            break;
          }

          // Progress log
          const elapsed = Math.floor((Date.now() - startTime) / 1000);
          if (elapsed > 0 && elapsed % 5 === 0 && elapsed !== lastLogTime) {
            lastLogTime = elapsed;
            const state = await checkIframeState(page);
            console.log(`[ts] ${elapsed}s — ${state ? state.detail : "no iframe"}`);
          }

          await new Promise(r => setTimeout(r, 1000));
        }

        if (intercepted) {
          await page.setRequestInterception(false).catch(() => {});
          page.off("request", responseHandler);
        }
        try { page.off("message", onMessage); } catch {}

        isResolved = true;
        clearTimeout(cl);

        if (!capturedToken || capturedToken.length < 10) {
          return reject(new Error("Failed to get token"));
        }

        console.log(`[ts] ✅ token OK (${capturedToken.length} chars)`);
        resolve({ token: capturedToken, type: "turnstile" });

      } catch (e) {
        console.log(`[ts] error: ${e.message}`);
        try { page.off("message", onMessage); } catch {}
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

// (Fungsi collectToken dan checkIframeState biarkan sama seperti sebelumnya)
async function collectToken(page, alreadyCaptured) {
  if (alreadyCaptured && alreadyCaptured.length >= 10) return alreadyCaptured;
  try {
    return await page.evaluate(() => {
      if (window.__cfToken && window.__cfToken.length >= 10) return window.__cfToken;
      if (window.__cfTokenCallback && window.__cfTokenCallback.length >= 10) return window.__cfTokenCallback;
      if (window.__cfTokenHooked && window.__cfTokenHooked.length >= 10) return window.__cfTokenHooked;
      const el = document.querySelector('input[name="cf-turnstile-response"]');
      if (el && el.value && el.value.length >= 10) return el.value;
      try {
        if (window.turnstile && typeof window.turnstile.getResponse === "function") {
          for (let i = 0; i < 10; i++) {
            try { const r = window.turnstile.getResponse(i); if (r && r.length >= 10) return r; } catch {}
          }
        }
      } catch {}
      for (const inp of document.querySelectorAll('input[type="hidden"]')) {
        if (inp.value && /^[01]\.[A-Za-z0-9_\-]{20,}/.test(inp.value)) return inp.value;
      }
      return null;
    });
  } catch { return null; }
}

async function checkIframeState(page) {
  try {
    const frames = page.frames();
    const f = frames.find(x => x.url().includes("challenges.cloudflare.com"));
    if (!f) return { key: "no-frame", detail: "state=no-iframe-yet" };

    const info = await f.evaluate(() => {
      const text = (document.body?.innerText || "").trim().replace(/\s+/g, " ");
      const lower = text.toLowerCase();
      return {
        text: text.slice(0, 60),
        hasCheckbox: !!document.querySelector('input[type="checkbox"], [role="checkbox"]'),
        hasChallenge: !!document.querySelector('img[src*="challenge"]'),
        hasSpinner: !!document.querySelector('.spinner, [class*="loading"]'),
        errorCode: lower.includes("invalid sitekey") ? "invalid-sitekey" : null,
      };
    });

    if (info.errorCode) return { key: info.errorCode, detail: `state=${info.errorCode}` };
    if (info.hasChallenge) return { key: "challenge", detail: "state=challenge-image" };
    if (info.hasCheckbox) return { key: "checkbox", detail: "state=checkbox" };
    if (info.hasSpinner) return { key: "spinner", detail: "state=spinner" };
    return { key: "idle", detail: `state=idle text="${info.text}"` };
  } catch { return null; }
}

module.exports = turnstile;
/**
 * turnstile.js v8 — Cek window._turnstileToken + multi-source
 * Fix: site pakai callback, token ada di global variable
 */

async function turnstile({ domain, siteKey, action, proxy, referer }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 150000;
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      try {
        await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 });
      } catch (e) {}

      // ── Navigate ─────────────────────────────────────────
      const refHeader = referer || "https://www.google.com/";
      await page.setExtraHTTPHeaders({
        "Referer": refHeader,
        "Accept-Language": "en-US,en;q=0.9",
      });

      console.log(`${TAG} goto ${domain}/faucet/index.php`);
      await page.goto(`${domain.replace(/\/$/, "")}/faucet/index.php`, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      // Tunggu Turnstile native render
      await new Promise((r) => setTimeout(r, 7000));

      // ── Cek nilai global ─────────────────────────────────
      const checkGlobals = async () => {
        return await page.evaluate(() => {
          const info = {
            _turnstileToken: window._turnstileToken || null,
            __ts_token: window.__ts_token || null,
            keys: Object.keys(window).filter(k => 
              k.toLowerCase().includes("turnstile") ||
              k.toLowerCase().includes("tstoken") ||
              k.toLowerCase().includes("cftoken")
            ),
            inputVals: [],
          };
          // Cek semua input
          document.querySelectorAll("input, textarea").forEach(el => {
            if (el.value && el.value.length > 10) {
              info.inputVals.push({
                name: el.name,
                id: el.id,
                len: el.value.length,
                prefix: el.value.slice(0, 20),
              });
            }
          });
          return info;
        });
      };

      const g0 = await checkGlobals();
      console.log(`${TAG} initial globals: ${JSON.stringify(g0)}`);

      // ── Tunggu token muncul dari sumber manapun ─────────
      console.log(`${TAG} waiting for token (multi-source)...`);
      const tokenHandle = await page.waitForFunction(
        () => {
          // 1. Cek window._turnstileToken (site's callback)
          if (window._turnstileToken && window._turnstileToken.length >= 20) {
            return { src: "window._turnstileToken", token: window._turnstileToken };
          }
          // 2. Cek window.__ts_token
          if (window.__ts_token && window.__ts_token.length >= 20) {
            return { src: "window.__ts_token", token: window.__ts_token };
          }
          // 3. Cek semua input value panjang
          const inputs = document.querySelectorAll("input, textarea");
          for (const el of inputs) {
            const v = el.value || "";
            if (v.length >= 20 && (v.startsWith("0.") || v.startsWith("1.") || 
                el.name?.includes("turnstile") || el.name?.includes("cf-chl"))) {
              return { src: "input:" + (el.name || el.id), token: v };
            }
          }
          return false;
        },
        { timeout, polling: 500 }
      );

      const result = await tokenHandle.jsonValue();
      const token = result.token;
      console.log(`${TAG} token found via: ${result.src}`);

      isResolved = true;
      clearTimeout(cl);

      if (!token || token.length < 20) {
        reject(new Error("Failed to get token (len=" + (token ? token.length : 0) + ")"));
      } else {
        console.log(`${TAG} ✅ solved, token len=${token.length}`);
        resolve({ token, type: "turnstile" });
      }

    } catch (e) {
      console.log(`${TAG} ❌ ${e?.name || "Error"}: ${e?.message || "unknown"}`);

      // Sebelum reject, dump semua global state untuk debug
      try {
        const dump = await page.evaluate(() => {
          const out = {};
          Object.keys(window).forEach(k => {
            if (k.toLowerCase().includes("turnstile") || k.toLowerCase().includes("token")) {
              try {
                const v = window[k];
                if (typeof v === "string" && v.length > 5) {
                  out[k] = v.slice(0, 40) + "...";
                } else {
                  out[k] = typeof v;
                }
              } catch (e) {}
            }
          });
          return out;
        });
        console.log(`${TAG} final globals dump: ${JSON.stringify(dump)}`);
      } catch (e) {}

      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
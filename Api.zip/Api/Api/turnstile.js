/**
 * test_minimal_inject.js
 * Test apakah intercept request + minimal HTML bisa solve Turnstile
 */
"use strict";

const { connect } = require("puppeteer-real-browser");

const SITEKEY = "0x4AAAAAAFkfYm8hLuheqVuc";
const TARGET_URL = "https://memecoinwatch.ai/final-sol-claim";

function buildMinimalHTML(sitekey) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Verify</title>
<style>body{padding:60px;font-family:system-ui,sans-serif;background:#f5f5f5}
#cf-container{display:flex;justify-content:center;margin:30px 0}
#status{text-align:center;font-size:14px;color:#333}</style>
</head>
<body>
<h1 style="text-align:center">Turnstile Solver</h1>
<div id="cf-container" class="cf-turnstile"></div>
<div id="status">Loading Turnstile...</div>
<script>
  window.__cfToken = null;
  window.__cfError = null;
  window.__cfLoaded = false;

  window.onTsLoad = function() {
    window.__cfLoaded = true;
    document.getElementById('status').textContent = 'Rendering widget...';
    try {
      window.turnstile.render('#cf-container', {
        sitekey: '${sitekey}',
        callback: function(token) {
          window.__cfToken = token;
          document.getElementById('status').textContent =
            'SUCCESS (' + token.length + ' chars)';
          var inp = document.createElement('input');
          inp.type = 'hidden';
          inp.name = 'cf-turnstile-response';
          inp.value = token;
          document.body.appendChild(inp);
        },
        'error-callback': function(code) {
          window.__cfError = code;
          document.getElementById('status').textContent = 'ERROR: ' + code;
        }
      });
    } catch (e) {
      document.getElementById('status').textContent = 'Render err: ' + e.message;
    }
  };
</script>
<script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onTsLoad" async defer></script>
</body>
</html>`;
}

async function main() {
  console.log("=".repeat(60));
  console.log(" MINIMAL HTML INJECT TEST");
  console.log("=".repeat(60));

  console.log("[+] Launching browser...");
  const { browser, page } = await connect({
    headless: false,
    disableXvfb: false,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-blink-features=AutomationControlled",
      "--disable-notifications",
      "--window-size=1366,768",
      "--lang=en-US,en",
      // DNS bypass (WAJIB kalau di Railway)
      "--host-resolver-rules=MAP challenges.cloudflare.com 104.16.132.229, MAP *.challenges.cloudflare.com 104.16.132.229",
      "--dns-over-https-mode=secure",
      "--dns-over-https-templates=https://cloudflare-dns.com/dns-query",
    ],
  });

  console.log("[+] Enabling request interception...");
  await page.setRequestInterception(true);

  let intercepted = false;
  page.on("request", (req) => {
    const url = req.url();
    const type = req.resourceType();

    if (type === "document" && url.includes("/final-sol-claim")) {
      if (!intercepted) {
        console.log(`[req] >>> INTERCEPT DOCUMENT: ${url}`);
        console.log(`[req] >>> Serving minimal HTML instead`);
        intercepted = true;
      }
      req.respond({
        status: 200,
        contentType: "text/html; charset=utf-8",
        body: buildMinimalHTML(SITEKEY),
      });
    } else {
      // Penting: log request penting saja
      if (url.includes("challenges.cloudflare.com") ||
          url.includes("turnstile")) {
        console.log(`[req] ${type.padEnd(10)} ${url.slice(0, 90)}`);
      }
      req.continue();
    }
  });

  page.on("requestfailed", (req) => {
    const url = req.url();
    if (url.includes("cloudflare") || url.includes("turnstile")) {
      const f = req.failure();
      console.log(`[REQFAIL] ${url.slice(0, 80)} — ${f ? f.errorText : "?"}`);
    }
  });

  page.on("console", (msg) => {
    const t = msg.text();
    if (t.includes("turnstile") || t.includes("challenge") ||
        t.includes("[cf]")) {
      console.log(`[browser] ${t.slice(0, 200)}`);
    }
  });

  console.log(`[+] Navigating to ${TARGET_URL}...`);
  try {
    await page.goto(TARGET_URL, {
      waitUntil: "domcontentloaded",
      timeout: 30000,
    });
  } catch (e) {
    console.log(`[!] Nav warning: ${e.message}`);
  }

  // Tunggu token
  console.log("[+] Waiting for token (max 120s)...");
  const start = Date.now();
  let token = null;
  let lastState = "";

  while (Date.now() - start < 120000) {
    try {
      token = await page.evaluate(() => window.__cfToken || null);
      const err = await page.evaluate(() => window.__cfError || null);
      const loaded = await page.evaluate(() => window.__cfLoaded || false);

      if (token) {
        console.log(`[✓] TOKEN OK in ${Math.floor((Date.now() - start) / 1000)}s`);
        break;
      }
      if (err) {
        console.log(`[✗] Widget error code: ${err}`);
        break;
      }

      // Progress log per 5 detik
      const elapsed = Math.floor((Date.now() - start) / 1000);
      if (elapsed > 0 && elapsed % 5 === 0 && elapsed !== parseInt(lastState)) {
        lastState = elapsed.toString();
        console.log(`[..] ${elapsed}s — loaded=${loaded} token=null`);

        // Cek iframe CF
        const frames = page.frames();
        const cfFrame = frames.find(f => f.url().includes("challenges.cloudflare.com"));
        if (cfFrame) {
          const info = await cfFrame.evaluate(() => ({
            text: (document.body?.innerText || "").slice(0, 80),
            hasCheckbox: !!document.querySelector('input[type="checkbox"]'),
            hasSpinner: !!document.querySelector('.spinner, [class*="loading"]'),
          })).catch(() => null);
          console.log(`[..] iframe: ${JSON.stringify(info)}`);
        } else {
          console.log(`[..] iframe: not found (frames=${frames.length})`);
        }
      }
    } catch {}
    await new Promise(r => setTimeout(r, 1000));
  }

  console.log("");
  console.log("=".repeat(60));
  if (token) {
    console.log(" RESULT: SUCCESS ✅");
    console.log("=".repeat(60));
    console.log(` Length : ${token.length}`);
    console.log(` Prefix : ${token.substring(0, 5)}`);
    console.log(` Token  : ${token.slice(0, 80)}...`);
  } else {
    console.log(" RESULT: FAILED ❌");
    console.log("=".repeat(60));
    console.log(" Cek log [REQFAIL] di atas — kemungkinan DNS masih salah");
  }
  console.log("=".repeat(60));

  await browser.close();
}

main().catch((e) => {
  console.error("FATAL:", e);
  process.exit(1);
});
async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 60000; // default 60 detik

  return new Promise(async (resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, timeout);

    try {
      // Proxy authentication (jika ada)
      if (proxy?.username && proxy?.password) {
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      // HTML halaman dengan widget Turnstile
      const htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
        <body>
          <div class="turnstile"></div>
          <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onloadTurnstileCallback" defer></script>
          <script>
            window.onloadTurnstileCallback = function () {
              turnstile.render('.turnstile', {
                sitekey: '${siteKey}',
                action: '${action || ""}'
                // Tidak perlu callback, kita akan baca elemen bawaan
              });
            };
          </script>
        </body>
        </html>
      `;

      // Intercept request untuk menyuntikkan HTML
      await page.setRequestInterception(true);
      page.removeAllListeners("request");
      page.on("request", async (request) => {
        if ([domain, domain + "/"].includes(request.url()) && request.resourceType() === "document") {
          await request.respond({
            status: 200,
            contentType: "text/html",
            body: htmlContent,
          });
        } else {
          await request.continue();
        }
      });

      await page.goto(domain, { waitUntil: "domcontentloaded" });

      // === DIAGNOSIS (opsional, untuk debugging) ===
      /*
      const debugInfo = await page.evaluate(() => ({
        turnstileLoaded: typeof window.turnstile !== 'undefined',
        iframeCount: document.querySelectorAll('iframe').length,
        responseInput: !!document.querySelector('[name="cf-turnstile-response"]')
      }));
      console.log('Debug Turnstile:', debugInfo);
      */

      // === TUNGGU HINGGA TOKEN TERISI (panjang > 10) ===
      const tokenHandle = await page.waitForFunction(
        () => {
          const el = document.querySelector('[name="cf-turnstile-response"]');
          return el && el.value && el.value.length > 10 ? el.value : false;
        },
        { timeout, polling: 200 } // polling setiap 200ms
      );

      const token = await tokenHandle.jsonValue();

      // Bersihkan timeout dan resolve
      isResolved = true;
      clearTimeout(cl);

      if (!token || token.length < 10) {
        reject(new Error("Failed to get token"));
      } else {
        resolve({ token, type: 'turnstile' });
      }
    } catch (e) {
      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
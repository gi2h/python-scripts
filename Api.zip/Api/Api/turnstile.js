/**
 * turnstile.js v9 — Auto-click checkbox (last resort)
 */

async function turnstile({ domain, siteKey, action, proxy, referer }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 150000;
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({ username: proxy.username, password: proxy.password });
      }

      try { await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 }); } catch (e) {}

      // ── Navigate ─────────────────────────────────────────
      await page.setExtraHTTPHeaders({
        "Referer": referer || "https://www.google.com/",
        "Accept-Language": "en-US,en;q=0.9",
      });

      console.log(`${TAG} goto ${domain}/faucet/index.php`);
      await page.goto(`${domain.replace(/\/$/, "")}/faucet/index.php`, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      await new Promise((r) => setTimeout(r, 6000));

      // ── Fungsi helper: cek token ─────────────────────────
      const getToken = async () => {
        return await page.evaluate(() => {
          if (window._turnstileToken && window._turnstileToken.length >= 20)
            return { src: "_turnstileToken", token: window._turnstileToken };
          if (window.__ts_token && window.__ts_token.length >= 20)
            return { src: "__ts_token", token: window.__ts_token };
          for (const el of document.querySelectorAll("input, textarea")) {
            const v = el.value || "";
            if (v.length >= 20 && (v.startsWith("0.") || v.startsWith("1.") ||
                el.name?.includes("turnstile") || el.name?.includes("cf-chl"))) {
              return { src: "input:" + (el.name || el.id), token: v };
            }
          }
          return null;
        });
      };

      const dumpGlobals = async () => {
        return await page.evaluate(() => {
          const out = {};
          Object.keys(window).forEach(k => {
            if (k.toLowerCase().includes("turnstile") || k.toLowerCase().includes("token")) {
              try {
                const v = window[k];
                if (typeof v === "string") out[k] = v.slice(0, 40) + (v.length > 40 ? "..." : "");
                else out[k] = typeof v;
              } catch (e) {}
            }
          });
          return out;
        });
      };

      // ── Cari & klik checkbox CF ─────────────────────────
      const tryClickCheckbox = async (attemptNum) => {
        console.log(`${TAG} click attempt #${attemptNum}`);

        // Scan semua frames
        const frames = page.frames();
        const cfFrames = frames.filter(f => f.url().includes("challenges.cloudflare.com"));
        console.log(`${TAG}   CF frames: ${cfFrames.length}`);

        for (const frame of cfFrames) {
          try {
            // Cari elemen checkbox / label di dalam iframe CF
            const info = await frame.evaluate(() => {
              const result = {
                hasCheckbox: false,
                checkboxInfo: null,
                bodyText: "",
                rect: null,
              };
              // Input checkbox
              const cb = document.querySelector('input[type="checkbox"]');
              if (cb) {
                result.hasCheckbox = true;
                const r = cb.getBoundingClientRect();
                result.checkboxInfo = { name: cb.name, id: cb.id, x: r.x, y: r.y, w: r.width, h: r.height };
                result.rect = { x: r.x, y: r.y, width: r.width, height: r.height };
              }
              // Cek label / div yang bisa diklik
              const clickable = document.querySelector('label, [role="button"], .ctp-checkbox-label, #challenge-stage');
              if (!result.rect && clickable) {
                const r = clickable.getBoundingClientRect();
                result.rect = { x: r.x, y: r.y, width: r.width, height: r.height };
              }
              result.bodyText = (document.body && document.body.innerText || "").slice(0, 200).replace(/\s+/g, " ");
              return result;
            });

            console.log(`${TAG}   frame body: "${info.bodyText}"`);
            if (info.rect) {
              console.log(`${TAG}   clickable rect: ${JSON.stringify(info.rect)}`);
            } else {
              console.log(`${TAG}   no clickable element, clicking frame center`);
            }

            // Klik via CDP di koordinat frame
            const frameElement = await frame.frameElement();
            if (frameElement) {
              const box = await frameElement.boundingBox();
              if (box) {
                // Klik di kiri-tengah iframe (di mana checkbox biasanya)
                const clickX = box.x + 25;
                const clickY = box.y + box.height / 2;
                console.log(`${TAG}   clicking at (${clickX}, ${clickY}) [left-center of iframe]`);
                await page.mouse.move(clickX - 10, clickY - 10);
                await new Promise(r => setTimeout(r, 100));
                await page.mouse.move(clickX, clickY);
                await new Promise(r => setTimeout(r, 100));
                await page.mouse.click(clickX, clickY);
                await new Promise(r => setTimeout(r, 500));
              }
            }
          } catch (e) {
            console.log(`${TAG}   frame click err: ${e.message}`);
          }
        }

        // Kalau tidak ada frame CF, klik di sekitar #turnstileBox
        if (cfFrames.length === 0) {
          try {
            const box = await page.$("#turnstileBox");
            if (box) {
              const bb = await box.boundingBox();
              if (bb) {
                console.log(`${TAG}   #turnstileBox bbox: ${JSON.stringify(bb)}`);
                await page.mouse.click(bb.x + 25, bb.y + bb.height / 2);
                console.log(`${TAG}   clicked #turnstileBox left-center`);
              }
            }
          } catch (e) {
            console.log(`${TAG}   #turnstileBox click err: ${e.message}`);
          }
        }
      };

      // ── Loop: klik berkala sampai token keluar ──────────
      console.log(`${TAG} starting click+wait loop`);
      const startTime = Date.now();
      let attempt = 0;
      let lastTokenCheck = 0;

      while (Date.now() - startTime < timeout) {
        attempt++;

        // Cek token dulu
        const t = await getToken();
        if (t) {
          isResolved = true;
          clearTimeout(cl);
          console.log(`${TAG} ✅ token via ${t.src}, len=${t.token.length}`);
          return resolve({ token: t.token, type: "turnstile" });
        }

        // Setiap attempt, klik checkbox
        await tryClickCheckbox(attempt);

        // Cek token lagi setelah klik
        await new Promise(r => setTimeout(r, 2000));
        const t2 = await getToken();
        if (t2) {
          isResolved = true;
          clearTimeout(cl);
          console.log(`${TAG} ✅ token via ${t2.src} after click, len=${t2.token.length}`);
          return resolve({ token: t2.token, type: "turnstile" });
        }

        // Log globals tiap 4 attempts
        if (attempt % 4 === 0) {
          const g = await dumpGlobals();
          console.log(`${TAG} [${attempt}] globals: ${JSON.stringify(g)}`);
          console.log(`${TAG} [${attempt}] elapsed: ${Math.round((Date.now() - startTime) / 1000)}s`);
        }

        // Delay antar click 3 detik
        await new Promise(r => setTimeout(r, 3000));
      }

      throw new Error("Click loop timeout");

    } catch (e) {
      console.log(`${TAG} ❌ ${e?.name || "Error"}: ${e?.message || "unknown"}`);
      try {
        const dump = await page.evaluate(() => {
          const out = {};
          Object.keys(window).forEach(k => {
            if (k.toLowerCase().includes("turnstile") || k.toLowerCase().includes("token")) {
              try {
                const v = window[k];
                out[k] = typeof v === "string" ? v.slice(0, 40) : typeof v;
              } catch (er) {}
            }
          });
          return out;
        });
        console.log(`${TAG} final globals: ${JSON.stringify(dump)}`);
      } catch (er) {}

      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
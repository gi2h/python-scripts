/**
 * turnstile.js v3 — Navigate normal + inject widget
 * Fix: Cloudflare tolak request.respond → pakai page.evaluate inject
 */

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 90000; // naikkan ke 90s
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;

    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      // ── Proxy auth ──────────────────────────────────────
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      // ── Viewport ────────────────────────────────────────
      try {
        await page.setViewport({
          width: 1366,
          height: 768,
          deviceScaleFactor: 1,
        });
      } catch (e) {
        console.log(`${TAG} setViewport warning: ${e.message}`);
      }

      // ── Step 1: Navigate ke domain asli ─────────────────
      console.log(`${TAG} goto ${domain} (native)`);
      await page.goto(domain, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      // Beri waktu page settle
      await new Promise((r) => setTimeout(r, 2000));

      // ── Step 2: Inject widget via evaluate ──────────────
      console.log(`${TAG} injecting Turnstile widget`);
      await page.evaluate(
        (injectedSiteKey, injectedAction) => {
          // Bersihkan widget lama
          document.querySelectorAll(".cf-turnstile").forEach((el) => el.remove());

          // Container baru
          const div = document.createElement("div");
          div.className = "cf-turnstile";
          div.style.cssText =
            "position:fixed;top:0;left:0;z-index:99999;background:#fff;padding:10px;";
          document.body.appendChild(div);

          // State global
          window.__ts_token = null;
          window.__ts_error = null;
          window.__ts_timeout = false;
          window.__ts_rendered = false;

          window.__ts_init = function () {
            try {
              window.turnstile.render(".cf-turnstile", {
                sitekey: injectedSiteKey,
                action: injectedAction || "",
                theme: "light",
                callback: function (token) {
                  window.__ts_token = token;
                  console.log("[ts-inject] ✅ token len=" + token.length);
                },
                "error-callback": function (e) {
                  window.__ts_error = e || "unknown";
                  console.log("[ts-inject] error: " + e);
                },
                "timeout-callback": function () {
                  window.__ts_timeout = true;
                  console.log("[ts-inject] timeout");
                },
                "expired-callback": function () {
                  window.__ts_token = null;
                  console.log("[ts-inject] expired");
                },
              });
              window.__ts_rendered = true;
              console.log("[ts-inject] render called");
            } catch (e) {
              window.__ts_error = "render-exception: " + e.message;
              console.log("[ts-inject] render error: " + e.message);
            }
          };

          // Load script kalau belum ada
          if (typeof window.turnstile === "undefined" || !window.turnstile.render) {
            console.log("[ts-inject] loading api.js");
            const s = document.createElement("script");
            s.src =
              "https://challenges.cloudflare.com/turnstile/v0/api.js?onload=__ts_onload";
            s.async = true;
            s.defer = true;
            window.__ts_onload = function () {
              console.log("[ts-inject] onload fired");
              window.__ts_init();
            };
            document.head.appendChild(s);
          } else {
            window.__ts_init();
          }
        },
        siteKey,
        action || ""
      );

      // ── Step 3: Tunggu token ────────────────────────────
      console.log(`${TAG} waiting for token...`);
      const tokenHandle = await page.waitForFunction(
        () => {
          if (window.__ts_token && window.__ts_token.length >= 10) {
            return window.__ts_token;
          }
          if (window.__ts_error) {
            throw new Error("Turnstile error: " + window.__ts_error);
          }
          if (window.__ts_timeout) {
            throw new Error("Turnstile timeout");
          }
          return false;
        },
        { timeout, polling: 500 }
      );

      const token = await tokenHandle.jsonValue();

      isResolved = true;
      clearTimeout(cl);

      if (!token || token.length < 10) {
        reject(
          new Error(
            "Failed to get token (len=" + (token ? token.length : 0) + ")"
          )
        );
      } else {
        console.log(`${TAG} ✅ solved, token len=${token.length}`);
        resolve({ token, type: "turnstile" });
      }
    } catch (e) {
      console.log(`${TAG} ❌ EXCEPTION`);
      console.log(`${TAG}   name    : ${e?.name || "(none)"}`);
      console.log(`${TAG}   message : ${e?.message || "(none)"}`);
      console.log(`${TAG}   stack   :`);
      console.log(e?.stack || "(no stack)");

      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
/**
 * turnstile.js — v7 FINAL + Real-time Iframe Monitor
 *
 * Monitoring yang ditambahkan:
 *   [ts-frame]         → navigasi/attach/detach iframe
 *   [ts-iframe]        → state iframe berubah (spinner/checkbox/success/error)
 *   [ts-iframe:console]→ console log dari dalam iframe Cloudflare
 *   [ts-iframe:error]  → pageerror dari dalam iframe
 *
 * Prinsip solve:
 *   1. Passive wait dulu (60% timeout)
 *   2. Klik HANYA kalau BENAR-BENAR ada checkbox
 *   3. Kalau tidak ada checkbox → jangan sentuh
 */

"use strict";

// ============================================================
// MAIN
// ============================================================
async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");

  let baseUrl = domain;
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = "https://" + baseUrl;
  const origin = new URL(baseUrl).origin;

  const totalTimeout = global.timeOut || 90000;
  const passiveWaitMs = Math.floor(totalTimeout * 0.6);
  const interactiveWaitMs = totalTimeout - passiveWaitMs;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, totalTimeout + 5000);

    (async () => {
      // ── Start monitor ────────────────────────────
      const monitor = startTurnstileMonitor(page);

      try {
        // ── UA & proxy ─────────────────────────────
        try {
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
          );
        } catch {}

        if (proxy && proxy.username && proxy.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        console.log(`[ts] navigate to ${origin}/`);

        await page.goto(origin + "/", {
          waitUntil: "domcontentloaded",
          timeout: 45000,
        });

        // ═══════════════════════════════════════════════════
        // FASE 1: Bot Management (interstitial)
        // ═══════════════════════════════════════════════════
        try {
          await page.waitForFunction(
            () => {
              const t = (document.title || "").toLowerCase();
              return !t.includes("just a moment") &&
                     !t.includes("checking your browser") &&
                     !t.includes("attention required");
            },
            { timeout: 25000, polling: 500 }
          );
          const title = await page.title();
          console.log(`[ts] page loaded: "${title.slice(0, 60)}"`);
        } catch {
          console.log(`[ts] WARN: bot challenge stuck > 25s`);
        }

        // ═══════════════════════════════════════════════════
        // FASE 2: Tunggu widget Turnstile muncul
        // ═══════════════════════════════════════════════════
        let widgetFound = false;
        try {
          await page.waitForSelector(
            ".cf-turnstile, iframe[src*='challenges.cloudflare.com']",
            { timeout: 15000, visible: true }
          );
          widgetFound = true;
          console.log(`[ts] widget detected`);
        } catch {
          console.log(`[ts] WARN: widget tidak muncul dalam 15s`);
        }

        if (!widgetFound) {
          throw new Error("Turnstile widget not found on page");
        }

        // ═══════════════════════════════════════════════════
        // FASE 3: PASSIVE WAIT
        // ═══════════════════════════════════════════════════
        console.log(`[ts] passive wait ${Math.floor(passiveWaitMs/1000)}s...`);

        let token = null;
        try {
          const tokenHandle = await page.waitForFunction(
            (minLength) => {
              const el = document.querySelector(
                'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
              );
              if (el && el.value && el.value.length >= minLength) {
                return { source: "input", token: el.value };
              }
              try {
                if (window.turnstile && typeof window.turnstile.getResponse === "function") {
                  for (let i = 0; i < 5; i++) {
                    try {
                      const r = window.turnstile.getResponse(i);
                      if (r && r.length >= minLength) {
                        return { source: "api", token: r };
                      }
                    } catch {}
                  }
                }
              } catch {}
              return false;
            },
            { timeout: passiveWaitMs, polling: 500 },
            10
          );

          const result = await tokenHandle.jsonValue();
          token = result.token;
          console.log(`[ts] ✅ token via ${result.source} (passive — no click needed)`);

        } catch (e) {
          console.log(`[ts] passive wait timed out — cek checkbox`);
        }

        // ═══════════════════════════════════════════════════
        // FASE 4: Interaksi checkbox (HANYA kalau ada)
        // ═══════════════════════════════════════════════════
        if (!token) {
          const checkboxFound = await findTurnstileCheckbox(page);

          if (!checkboxFound) {
            console.log(`[ts] TIDAK ada checkbox — tidak akan klik apapun`);
            console.log(`[ts] tunggu sisa ${Math.floor(interactiveWaitMs/1000)}s`);
          } else {
            console.log(`[ts] ✅ checkbox ditemukan di: ${checkboxFound.location}`);

            // Hover dulu (natural)
            try {
              await checkboxFound.element.hover();
              await sleep(300 + Math.random() * 400);
            } catch {}

            // Klik dengan delay natural
            try {
              await checkboxFound.element.click({
                delay: 80 + Math.floor(Math.random() * 120),
              });
              console.log(`[ts] 👆 clicked checkbox (single click, targeted)`);
            } catch (e) {
              console.log(`[ts] click error: ${e.message}`);
            }

            await sleep(1500 + Math.random() * 1000);
          }

          // Tunggu token di sisa waktu
          try {
            const tokenHandle = await page.waitForFunction(
              (minLength) => {
                const el = document.querySelector(
                  'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
                );
                if (el && el.value && el.value.length >= minLength) return el.value;
                try {
                  if (window.turnstile && typeof window.turnstile.getResponse === "function") {
                    for (let i = 0; i < 5; i++) {
                      try {
                        const r = window.turnstile.getResponse(i);
                        if (r && r.length >= minLength) return r;
                      } catch {}
                    }
                  }
                } catch {}
                return false;
              },
              { timeout: interactiveWaitMs, polling: 500 },
              10
            );

            token = await tokenHandle.jsonValue();
            console.log(`[ts] ✅ token after interaction (${token.length} chars)`);

          } catch (e) {
            console.log(`[ts] ❌ token tidak muncul setelah interaksi`);
          }
        }

        isResolved = true;
        clearTimeout(cl);
        monitor.stop();

        if (!token || token.length < 10) {
          return reject(new Error("Failed to get token"));
        }

        resolve({ token, type: "turnstile" });

      } catch (e) {
        console.log(`[ts] error: ${e.message}`);
        monitor.stop();
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

// ============================================================
// MONITOR — Real-time iframe tracking
// ============================================================
function startTurnstileMonitor(page) {
  let lastStateKey = null;
  let lastFrameUrl = null;
  let intervalId = null;
  let stopped = false;

  // ── Frame navigation ─────────────────────────────
  const onFrameNav = (frame) => {
    try {
      const url = frame.url();
      if (url.includes("challenges.cloudflare.com") && url !== lastFrameUrl) {
        lastFrameUrl = url;
        const short = url
          .replace("https://challenges.cloudflare.com/", "cf/")
          .slice(0, 120);
        console.log(`[ts-frame] navigated → ${short}`);
      }
    } catch {}
  };

  const onFrameAttached = (frame) => {
    try {
      const url = frame.url();
      if (url.includes("challenges.cloudflare.com")) {
        console.log(`[ts-frame] attached`);
      }
    } catch {}
  };

  const onFrameDetached = (frame) => {
    try {
      const url = frame.url();
      if (url.includes("challenges.cloudflare.com")) {
        console.log(`[ts-frame] detached (challenge finished)`);
      }
    } catch {}
  };

  // ── Console dari dalam iframe ────────────────────
  const onConsole = (msg) => {
    try {
      const loc = msg.location();
      const url = (loc && loc.url) || "";
      if (!url.includes("challenges.cloudflare.com")) return;

      const text = msg.text();
      // Skip noise yang tidak berguna
      if (text.includes("favicon") || text.includes("postMessage")) return;

      console.log(`[ts-iframe:console] [${msg.type()}] ${text.slice(0, 200)}`);
    } catch {}
  };

  const onPageError = (err) => {
    try {
      const stack = (err && err.stack) || "";
      const msg = (err && err.message) || String(err);
      // Hanya log kalau error datang dari iframe Cloudflare
      if (stack.includes("challenges.cloudflare.com")) {
        console.log(`[ts-iframe:error] ${msg.slice(0, 200)}`);
      }
    } catch {}
  };

  page.on("framenavigated", onFrameNav);
  page.on("frameattached", onFrameAttached);
  page.on("framedetached", onFrameDetached);
  page.on("console", onConsole);
  page.on("pageerror", onPageError);

  // ── Polling state tiap 1 detik ───────────────────
  intervalId = setInterval(async () => {
    if (stopped) return;
    try {
      const frames = page.frames();
      const tsFrame = frames.find(f =>
        f.url().includes("challenges.cloudflare.com") &&
        (f.url().includes("turnstile") || f.url().includes("challenge-platform"))
      );

      if (!tsFrame) {
        if (lastStateKey !== "frame-not-found") {
          lastStateKey = "frame-not-found";
          console.log(`[ts-iframe] frame belum ada`);
        }
        return;
      }

      // Query DOM di dalam iframe
      const info = await tsFrame.evaluate(() => {
        try {
          const body = document.body;
          if (!body) return { status: "empty" };

          const text = (body.innerText || "").replace(/\s+/g, " ").trim();
          const textLower = text.toLowerCase();
          const html = body.innerHTML || "";

          // Deteksi elemen
          const hasCheckboxInput = !!document.querySelector('input[type="checkbox"]');
          const hasCheckboxRole = !!document.querySelector('[role="checkbox"]');
          const hasCheckboxClass = !!document.querySelector(
            '.ctp-checkbox-label, .cb-lb, .checkbox-label, label[for*="checkbox"]'
          );

          const hasSpinner =
            !!document.querySelector('.spinner, [class*="spinner"], [class*="loading"]');

          const hasSuccess =
            !!document.querySelector('.success, [class*="success"], [class*="verified"]') ||
            !!document.querySelector('svg[class*="check"], svg[class*="tick"]');

          const hasChallengeImg =
            !!document.querySelector('img[src*="challenge"], .challenge-image, [class*="challenge-grid"]') ||
            html.includes("challenge-image");

          // Verifying text
          const verifying =
            textLower.includes("verifying") ||
            textLower.includes("checking") ||
            textLower.includes("loading");

          // Deteksi error spesifik
          let errorCode = null;
          if (textLower.includes("invalid sitekey") || textLower.includes("invalid-sitekey")) {
            errorCode = "invalid-sitekey";
          } else if (textLower.includes("invalid domain") || textLower.includes("invalid-domain")) {
            errorCode = "invalid-domain";
          } else if (textLower.includes("browser not supported")) {
            errorCode = "browser-not-supported";
          } else if (textLower.includes("expired")) {
            errorCode = "expired";
          } else if (textLower.includes("try again") || textLower.includes("failed")) {
            errorCode = "failed";
          } else if (textLower.includes("error")) {
            errorCode = "generic-error";
          }

          // aria-live region (Cloudflare kadang simpan status di sini)
          const live = document.querySelector('[aria-live]');
          const liveText = live ? (live.textContent || "").trim().slice(0, 80) : "";

          return {
            status: "loaded",
            text: text.slice(0, 120),
            liveText,
            hasCheckbox: hasCheckboxInput || hasCheckboxRole || hasCheckboxClass,
            hasCheckboxDetail: hasCheckboxInput ? "input" :
                               hasCheckboxRole ? "role" :
                               hasCheckboxClass ? "class" : null,
            hasSpinner,
            hasSuccess,
            hasChallengeImg,
            verifying,
            errorCode,
            size: `${body.scrollWidth}x${body.scrollHeight}`,
          };
        } catch (e) {
          return { status: "eval-error", error: e.message };
        }
      });

      // ── Bangun state key untuk diff ──────────────
      let stateKey;
      if (info.status !== "loaded") {
        stateKey = info.status;
      } else if (info.errorCode) {
        stateKey = `error:${info.errorCode}`;
      } else if (info.hasSuccess) {
        stateKey = "success";
      } else if (info.hasChallengeImg) {
        stateKey = "challenge-image";
      } else if (info.verifying) {
        stateKey = "verifying";
      } else if (info.hasCheckbox) {
        stateKey = `checkbox:${info.hasCheckboxDetail}`;
      } else if (info.hasSpinner) {
        stateKey = "spinner";
      } else {
        stateKey = "idle";
      }

      // ── Log kalau state berubah ──────────────────
      if (stateKey !== lastStateKey) {
        lastStateKey = stateKey;

        const parts = [`state=${stateKey}`];
        if (info.size) parts.push(`size=${info.size}`);
        if (info.text) parts.push(`text="${info.text.slice(0, 60)}"`);
        if (info.liveText) parts.push(`live="${info.liveText}"`);

        console.log(`[ts-iframe] ${parts.join(" | ")}`);
      }

    } catch {
      // Frame detached di tengah evaluate — abaikan
    }
  }, 1000);

  return {
    stop() {
      stopped = true;
      if (intervalId) clearInterval(intervalId);
      try { page.off("framenavigated", onFrameNav); } catch {}
      try { page.off("frameattached", onFrameAttached); } catch {}
      try { page.off("framedetached", onFrameDetached); } catch {}
      try { page.off("console", onConsole); } catch {}
      try { page.off("pageerror", onPageError); } catch {}
    }
  };
}

// ============================================================
// HELPER: Cari checkbox yang BENAR-BENAR ada
// ============================================================
async function findTurnstileCheckbox(page) {
  try {
    const frames = page.frames();

    for (const f of frames) {
      const url = f.url();
      if (!url.includes("challenges.cloudflare.com")) continue;
      if (!url.includes("turnstile") && !url.includes("challenge-platform")) continue;

      try {
        // Prioritas 1: input[type=checkbox] asli
        const cb = await f.$('input[type="checkbox"]');
        if (cb) {
          const visible = await cb.isIntersectingViewport().catch(() => false);
          if (visible) return { element: cb, location: "input[type=checkbox]" };
        }

        // Prioritas 2: label checkbox
        const label = await f.$('label[for*="checkbox"], .ctp-checkbox-label, .cb-lb');
        if (label) {
          const visible = await label.isIntersectingViewport().catch(() => false);
          if (visible) return { element: label, location: "checkbox label" };
        }

        // Prioritas 3: role=checkbox
        const roleCb = await f.$('[role="checkbox"]');
        if (roleCb) {
          const visible = await roleCb.isIntersectingViewport().catch(() => false);
          if (visible) return { element: roleCb, location: "role=checkbox" };
        }
      } catch {
        continue;
      }
    }
  } catch {}

  return null;
}

// ============================================================
// HELPERS
// ============================================================
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

module.exports = turnstile;
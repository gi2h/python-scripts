/**
 * turnstile.js v6 — WAIT native widget (no injection)
 * Fix: halaman sudah punya Turnstile native, jangan inject kedua
 */

async function turnstile({ domain, siteKey, action, proxy, referer }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  const timeout = global.timeOut || 120000;
  const TAG = "[turnstile]";

  return new Promise(async (resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error after " + timeout + "ms"));
      }
    }, timeout);

    try {
      if (proxy?.username && proxy?.password) {
        console.log(`${TAG} proxy auth`);
        await page.authenticate({
          username: proxy.username,
          password: proxy.password,
        });
      }

      try {
        await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 });
      } catch (e) {}

      // ── Navigate ────────────────────────────────────────
      const refHeader = referer || "https://www.google.com/";
      await page.setExtraHTTPHeaders({
        "Referer": refHeader,
        "Accept-Language": "en-US,en;q=0.9",
      });

      console.log(`${TAG} goto ${domain}/faucet/index.php`);
      await page.goto(`${domain.replace(/\/$/, "")}/faucet/index.php`, {
        waitUntil: "domcontentloaded",
        timeout: Math.min(timeout, 45000),
      });

      // Biarkan halaman settle + Turnstile native load
      await new Promise((r) => setTimeout(r, 5000));

      // ── Scan semua frame & element untuk Turnstile ─────
      console.log(`${TAG} scanning for Turnstile widgets...`);

      // Scan DOM + semua iframes
      const scanResult = await page.evaluate(() => {
        const report = {
          divs: [],
          inputs: [],
          iframes: [],
          dataSitekeys: [],
        };

        // Cek div.cf-turnstile
        document.querySelectorAll(".cf-turnstile").forEach((el) => {
          report.divs.push({
            visible: !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length),
            sitekey: el.getAttribute("data-sitekey") || null,
          });
        });

        // Cek input hidden
        document.querySelectorAll('input[name="cf-turnstile-response"]').forEach((el) => {
          report.inputs.push({
            id: el.id,
            value: el.value ? el.value.slice(0, 30) + "..." : "",
            len: el.value ? el.value.length : 0,
          });
        });

        // Cek iframe challenges.cloudflare.com
        document.querySelectorAll("iframe").forEach((f) => {
          if (f.src && f.src.includes("challenges.cloudflare.com")) {
            report.iframes.push({
              src: f.src.slice(0, 100),
              width: f.offsetWidth,
              height: f.offsetHeight,
            });
          }
        });

        // Cek semua data-sitekey
        document.querySelectorAll("[data-sitekey]").forEach((el) => {
          report.dataSitekeys.push({
            tag: el.tagName,
            sitekey: el.getAttribute("data-sitekey"),
          });
        });

        return report;
      });

      console.log(`${TAG} DOM scan:`);
      console.log(`  divs: ${JSON.stringify(scanResult.divs)}`);
      console.log(`  inputs: ${JSON.stringify(scanResult.inputs)}`);
      console.log(`  iframes: ${JSON.stringify(scanResult.iframes)}`);
      console.log(`  dataSitekeys: ${JSON.stringify(scanResult.dataSitekeys)}`);

      // ── Scan semua page frames ──────────────────────────
      const frames = page.frames();
      console.log(`${TAG} total frames: ${frames.length}`);
      for (const f of frames) {
        const url = f.url();
        if (url.includes("challenges.cloudflare.com")) {
          console.log(`${TAG}   CF frame: ${url.slice(0, 100)}`);
        }
      }

      // ── Tunggu token di SEMUA input yang mungkin ───────
      console.log(`${TAG} waiting for token (native)...`);

      const tokenHandle = await page.waitForFunction(
        () => {
          // Cek input name cf-turnstile-response
          const inputs = document.querySelectorAll('input, textarea');
          for (const el of inputs) {
            const name = (el.name || "").toLowerCase();
            const id = (el.id || "").toLowerCase();
            if ((name.includes("turnstile") || id.includes("turnstile")) &&
                el.value && el.value.length >= 20) {
              return el.value;
            }
          }
          // Cek input apa saja yang punya value panjang (fallback)
          for (const el of inputs) {
            if (el.value && el.value.length >= 100 &&
                el.value.startsWith("0.")) {
              return el.value;
            }
          }
          return false;
        },
        { timeout, polling: 500 }
      );

      const token = await tokenHandle.jsonValue();
      isResolved = true;
      clearTimeout(cl);

      if (!token || token.length < 20) {
        reject(new Error("Failed to get token (len=" + (token ? token.length : 0) + ")"));
      } else {
        console.log(`${TAG} ✅ solved, token len=${token.length}`);
        resolve({ token, type: "turnstile" });
      }

    } catch (e) {
      console.log(`${TAG} ❌ ${e?.name || "Error"}: ${e?.message || "unknown"}`);
      if (!isResolved) {
        isResolved = true;
        clearTimeout(cl);
        reject(e);
      }
    }
  });
}

module.exports = turnstile;
async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");
  if (!siteKey) throw new Error("Missing siteKey parameter");

  // ── Normalisasi domain ────────────────────────────────────
  let baseUrl = domain;
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = "https://" + baseUrl;
  const u = new URL(baseUrl);
  const origin = u.origin;               // https://freelitecoin.online
  const mainDocUrls = [origin + "/", origin];

  const timeout = global.timeOut || 60000;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, timeout + 5000);

    (async () => {
      try {
        // ── User agent konsisten (biar tidak "headless-like") ─
        try {
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
          );
        } catch {}

        // ── Proxy auth ───────────────────────────────────────
        if (proxy?.username && proxy?.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        // ── HTML yang menyuntikkan widget Turnstile ──────────
        const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>Verify</title>
</head>
<body>
  <div class="cf-turnstile"></div>
  <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onloadTurnstileCallback" defer></script>
  <script>
    window.onloadTurnstileCallback = function () {
      try {
        turnstile.render('.cf-turnstile', {
          sitekey: '${siteKey}',
          action: '${action || ""}',
          callback: function (t) { window.__tsToken = t; }
        });
      } catch (e) { console.error('ts render error', e); }
    };
  </script>
</body>
</html>`;

        // ── Interception yang lebih aman ─────────────────────
        await page.setRequestInterception(true);

        const onRequest = async (request) => {
          try {
            const url = request.url();
            const rtype = request.resourceType();

            // HANYA ganti dokumen utama. Jangan sentuh iframe/script
            // Cloudflare, jangan sentuh resource lain.
            if (rtype === "document" && mainDocUrls.includes(url)) {
              return await request.respond({
                status: 200,
                contentType: "text/html; charset=utf-8",
                body: htmlContent,
              });
            }
            // Semua sisanya diteruskan apa adanya
            return await request.continue();
          } catch {
            try { await request.continue(); } catch {}
          }
        };

        page.on("request", onRequest);

        // ── Buka halaman ─────────────────────────────────────
        await page.goto(origin + "/", {
          waitUntil: "domcontentloaded",
          timeout: 30000,
        });

        // ── Tunggu token muncul (input ATAU textarea ATAU __tsToken)
        const tokenHandle = await page.waitForFunction(
          (minLength) => {
            if (window.__tsToken && window.__tsToken.length >= minLength)
              return window.__tsToken;

            const el = document.querySelector(
              'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
            );
            if (el && el.value && el.value.length >= minLength) return el.value;

            return false;
          },
          { timeout, polling: 500 },
          10
        );

        const token = await tokenHandle.jsonValue();

        try { page.off("request", onRequest); } catch {}

        isResolved = true;
        clearTimeout(cl);

        if (!token || token.length < 10) {
          return reject(new Error("Failed to get token"));
        }
        resolve({ token, type: "turnstile" });

      } catch (e) {
        try { page.off("request", onRequest); } catch {}
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

module.exports = turnstile;
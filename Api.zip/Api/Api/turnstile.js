/**
 * turnstile.js — v5 FINAL
 * Load halaman asli, tunggu Bot Management selesai, ambil token.
 * Support implicit rendering (data-sitekey) & explicit rendering.
 */

"use strict";

async function turnstile({ domain, siteKey, action, proxy }, page) {
  if (!domain) throw new Error("Missing domain parameter");

  let baseUrl = domain;
  if (!/^https?:\/\//i.test(baseUrl)) baseUrl = "https://" + baseUrl;
  const origin = new URL(baseUrl).origin;

  const timeout = global.timeOut || 90000;

  return new Promise((resolve, reject) => {
    let isResolved = false;
    const cl = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        reject(new Error("Timeout Error"));
      }
    }, timeout + 5000);

    (async () => {
      try {
        // ── UA konsisten ─────────────────────────────
        try {
          await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
          );
        } catch {}

        // ── Proxy auth ───────────────────────────────
        if (proxy && proxy.username && proxy.password) {
          await page.authenticate({
            username: proxy.username,
            password: proxy.password,
          });
        }

        console.log(`[ts] navigate to ${origin}/`);

        await page.goto(origin + "/", {
          waitUntil: "domcontentloaded",
          timeout: 45000,
        });

        // ── Fase 1: Tunggu Bot Management selesai ────
        // Cloudflare interstitial biasanya hilang dalam 5-20s.
        // Kalau lebih, kemungkinan IP diblokir.
        try {
          await page.waitForFunction(
            () => {
              const t = (document.title || "").toLowerCase();
              return !t.includes("just a moment") &&
                     !t.includes("checking your browser") &&
                     !t.includes("attention required");
            },
            { timeout: 25000, polling: 500 }
          );
          const title = await page.title();
          console.log(`[ts] page loaded: "${title.slice(0, 60)}"`);
        } catch {
          console.log(`[ts] WARN: bot challenge stuck > 25s (kemungkinan IP diblokir)`);
        }

        // ── Fase 2: Tunggu widget Turnstile muncul ───
        let widgetFound = false;
        try {
          await page.waitForSelector(".cf-turnstile, iframe[src*='challenges.cloudflare.com']", {
            timeout: 20000,
            visible: true,
          });
          widgetFound = true;
          console.log(`[ts] widget detected`);
        } catch {
          console.log(`[ts] WARN: widget tidak muncul dalam 20s`);
        }

        if (!widgetFound) {
          throw new Error("Turnstile widget not found on page");
        }

        // ── Fase 3: Auto-klik checkbox jika ada ──────
        // Cloudflare Turnstile kadang butuh interaksi klik.
        setTimeout(async () => {
          try {
            const frames = page.frames();
            for (const f of frames) {
              const u = f.url();
              if (u.includes("challenges.cloudflare.com") &&
                  (u.includes("challenge-platform") || u.includes("turnstile"))) {
                try {
                  // Coba klik di area checkbox
                  const cb = await f.$('input[type="checkbox"]');
                  if (cb) {
                    console.log(`[ts] clicking checkbox`);
                    await cb.click();
                    return;
                  }
                  // Fallback: klik body iframe
                  const body = await f.$("body");
                  if (body) {
                    const box = await body.boundingBox();
                    if (box && box.width > 0) {
                      await page.mouse.click(box.x + 30, box.y + box.height / 2);
                      console.log(`[ts] clicked iframe area`);
                      return;
                    }
                  }
                } catch {}
              }
            }
          } catch {}
        }, 3000);

        // ── Fase 4: Tunggu token ─────────────────────
        const tokenHandle = await page.waitForFunction(
          (minLength) => {
            // Cara 1: input hidden auto-generated
            const el = document.querySelector(
              'input[name="cf-turnstile-response"], textarea[name="cf-turnstile-response"]'
            );
            if (el && el.value && el.value.length >= minLength) return el.value;

            // Cara 2: window.turnstile.getResponse()
            try {
              if (window.turnstile && typeof window.turnstile.getResponse === "function") {
                for (let i = 0; i < 5; i++) {
                  try {
                    const r = window.turnstile.getResponse(i);
                    if (r && r.length >= minLength) return r;
                  } catch {}
                }
              }
            } catch {}

            return false;
          },
          { timeout, polling: 500 },
          10
        );

        const token = await tokenHandle.jsonValue();

        isResolved = true;
        clearTimeout(cl);

        if (!token || token.length < 10) {
          return reject(new Error("Failed to get token"));
        }

        console.log(`[ts] ✅ token OK (${token.length} chars)`);
        resolve({ token, type: "turnstile" });

      } catch (e) {
        console.log(`[ts] error: ${e.message}`);
        if (!isResolved) {
          isResolved = true;
          clearTimeout(cl);
          reject(e);
        }
      }
    })();
  });
}

module.exports = turnstile;
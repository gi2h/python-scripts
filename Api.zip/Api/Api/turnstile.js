/**
 * turnstile.js — v16.0 DEEP IFRAME INSPECTOR
 */
"use strict";

const MINIMAL_HTML = (sitekey) => `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Verification</title>
    <style>
        body { padding: 50px; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; }
        #cf-container { margin: 20px 0; }
        #status { font-size: 14px; color: #333; }
    </style>
</head>
<body>
    <h2>Security Check</h2>
    <div id="cf-container" class="cf-turnstile"></div>
    <div id="status">Waiting for Turnstile...</div>
    <script>
        window.__cfToken = null;
        window.__cfError = null;
        window.__cfLoaded = false;

        window.onloadCallback = function() {
            window.__cfLoaded = true;
            document.getElementById('status').textContent = 'Rendering widget...';
            try {
                window.turnstile.render('#cf-container', {
                    sitekey: '${sitekey}',
                    callback: function(token) {
                        window.__cfToken = token;
                        document.getElementById('status').textContent = 'Success!';
                        let input = document.querySelector('input[name="cf-turnstile-response"]');
                        if (!input) {
                            input = document.createElement('input');
                            input.type = 'hidden';
                            input.name = 'cf-turnstile-response';
                            document.body.appendChild(input);
                        }
                        input.value = token;
                    },
                    'error-callback': function(code) {
                        window.__cfError = code;
                        document.getElementById('status').textContent = 'Error: ' + code;
                    }
                });
            } catch (e) {
                document.getElementById('status').textContent = 'Render Error: ' + e.message;
            }
        };
    </script>
    <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit&onload=onloadCallback" async defer></script>
</body>
</html>`;

async function turnstile({ domain, siteKey, proxy }, page) {
    if (!domain) throw new Error("Missing domain parameter");
    if (!siteKey) throw new Error("Missing siteKey parameter");

    let targetUrl = domain;
    if (!/^https?:\/\//i.test(targetUrl)) targetUrl = "https://" + targetUrl;
    
    const targetHost = new URL(targetUrl).hostname;
    const totalTimeout = global.timeOut || 120000;

    return new Promise((resolve, reject) => {
        let isResolved = false;
        let capturedToken = null;

        const timeoutTimer = setTimeout(() => {
            if (!isResolved) {
                isResolved = true;
                reject(new Error("Timeout Error"));
            }
        }, totalTimeout + 5000);

        (async () => {
            const onMessage = (msg) => {
                try {
                    const text = typeof msg === "string" ? msg : JSON.stringify(msg);
                    if (!text) return;
                    const m = text.match(/[01]\.[A-Za-z0-9_\-]{100,}/);
                    if (m && !capturedToken) {
                        capturedToken = m[0];
                        console.log(`[ts-msg] 🎯 Token via postMessage (${capturedToken.length} chars)`);
                    }
                } catch {}
            };
            page.on("message", onMessage);

            try {
                if (proxy && proxy.username && proxy.password) {
                    await page.authenticate({
                        username: proxy.username,
                        password: proxy.password,
                    });
                    console.log(`[ts] Proxy auth set.`);
                }

                console.log(`[ts] Mengaktifkan intercept HANYA untuk ${targetHost}...`);
                await page.setRequestInterception(true);
                
                const requestHandler = (req) => {
                    const reqUrl = req.url();
                    const type = req.resourceType();

                    if (type === "document" && reqUrl.includes(targetHost)) {
                        console.log(`[ts] Injecting minimal HTML ke: ${reqUrl}`);
                        req.respond({
                            status: 200,
                            contentType: "text/html; charset=utf-8",
                            body: MINIMAL_HTML(siteKey),
                        });
                    } else {
                        req.continue();
                    }
                };
                page.on("request", requestHandler);

                console.log(`[ts] Navigasi ke: ${targetUrl}`);
                await page.goto(targetUrl, { waitUntil: "domcontentloaded", timeout: 45000 });

                const startTime = Date.now();
                let lastState = "";
                let hasClicked = false;

                while (Date.now() - startTime < totalTimeout) {
                    if (capturedToken) break;

                    // 1. Cek Token (Dinamis dari root dom / callback)
                    const tok = await page.evaluate(() => {
                        if (window.__cfToken) return window.__cfToken;
                        if (window.__cfTokenCallback) return window.__cfTokenCallback;
                        if (window.__cfTokenHooked) return window.__cfTokenHooked;
                        const el = document.querySelector('input[name="cf-turnstile-response"]');
                        if (el && el.value) return el.value;
                        // Cek via API Cloudflare
                        if (window.turnstile && typeof window.turnstile.getResponse === 'function') {
                            try {
                                const r = window.turnstile.getResponse();
                                if (r) return r;
                            } catch(e){}
                        }
                        return null;
                    }).catch(() => null);
                    
                    if (tok) {
                        capturedToken = tok;
                        break;
                    }

                    // 2. Inspeksi Iframe (Mata Kita)
                    const frames = page.frames();
                    const cfFrame = frames.find(f => f.url().includes("challenges.cloudflare.com"));
                    
                    if (cfFrame) {
                        try {
                            // Dapatkan teks dan status di dalam iframe
                            const frameData = await cfFrame.evaluate(() => {
                                const text = (document.body?.innerText || "").trim().replace(/\s+/g, " ");
                                const checkbox = document.querySelector('input[type="checkbox"]');
                                const spinner = document.querySelector('.spinner, [class*="loading"]');
                                const success = document.querySelector('.success, [class*="success"]');
                                
                                // Coba klik checkbox jika ada
                                if (checkbox && !checkbox.checked) {
                                    checkbox.click();
                                    return { text, action: "clicked_checkbox" };
                                }
                                return { 
                                    text, 
                                    action: "none",
                                    hasCheckbox: !!checkbox,
                                    hasSpinner: !!spinner,
                                    hasSuccess: !!success
                                };
                            }).catch((err) => ({ text: "EVAL_ERROR: " + err.message, action: "error" }));

                            // Log isi iframe setiap 5 detik
                            const elapsed = Math.floor((Date.now() - startTime) / 1000);
                            if (elapsed > 0 && elapsed % 5 === 0 && elapsed !== lastState) {
                                lastState = elapsed;
                                console.log(`[ts-iframe] ${elapsed}s | Text: "${frameData.text.slice(0, 80)}" | Checkbox: ${frameData.hasCheckbox} | Spinner: ${frameData.hasSpinner}`);
                                
                                if (frameData.action === "clicked_checkbox") {
                                    console.log(`[ts] 👆 Checkbox diklik secara dinamis via DOM!`);
                                }
                            }
                        } catch (e) {
                            // Abaikan error cross-origin sementara
                        }
                    } else {
                        const elapsed = Math.floor((Date.now() - startTime) / 1000);
                        if (elapsed > 0 && elapsed % 5 === 0 && elapsed !== lastState) {
                            lastState = elapsed;
                            console.log(`[ts] ${elapsed}s — Menunggu iframe Cloudflare...`);
                        }
                    }

                    await new Promise(r => setTimeout(r, 1000));
                }

                page.off("request", requestHandler);
                await page.setRequestInterception(false).catch(() => {});
                page.off("message", onMessage);

                isResolved = true;
                clearTimeout(timeoutTimer);

                if (!capturedToken || capturedToken.length < 10) {
                    throw new Error("Gagal mendapatkan token setelah timeout.");
                }

                console.log(`[ts] ✅ Token berhasil didapat (${capturedToken.length} chars).`);
                resolve({ token: capturedToken, type: "turnstile" });

            } catch (e) {
                console.log(`[ts] ❌ Error: ${e.message}`);
                if (!isResolved) {
                    isResolved = true;
                    clearTimeout(timeoutTimer);
                    reject(e);
                }
            }
        })();
    });
}

module.exports = turnstile;
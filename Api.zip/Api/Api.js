/**
 * API.js
 * SUPER ROBUST / LOW RAM
 *
 * Designed for:
 *   VPS 2 GB RAM
 *   MAX 2 concurrent browsers
 *   MAX 4 waiting tasks
 *
 * Lifecycle:
 *
 *   request
 *      ↓
 *   pending
 *      ↓
 *   queue <= 60s
 *      ↓
 *   processing
 *      ↓
 *   browser/solver <= 120s
 *      ↓
 *   done / error / timeout / browser_error
 *      ↓
 *   browser cleanup
 *      ↓
 *   task result
 *
 * IMPORTANT:
 * This file manages task lifecycle and browser cleanup.
 * Solver implementation remains in ./Api/*.js
 */

"use strict";

const express = require("express");
const { connect } = require("puppeteer-real-browser");

// ============================================================
// CONFIG
// ============================================================

const PORT = Number(process.env.PORT || 8080);

const AUTH_TOKEN =
    process.env.authToken || null;

// -----------------------------
// LOW RAM LIMITS
// -----------------------------

const MAX_BROWSERS = 2;
const MAX_QUEUE = 4;

// -----------------------------
// HARD TIME LIMITS
// -----------------------------

// Task boleh menunggu di queue:
const QUEUE_TIMEOUT = 60 * 1000;

// Browser + solver maksimal hidup:
const BROWSER_TIMEOUT = 120 * 1000;

// Beri sedikit waktu tambahan untuk cleanup:
const CLEANUP_TIMEOUT = 10 * 1000;

// -----------------------------
// Task result TTL
// -----------------------------

const RESULT_TTL = 5 * 60 * 1000;

// -----------------------------
// Browser launch timeout
// -----------------------------

const LAUNCH_TIMEOUT = 30 * 1000;

// ============================================================
// EXPRESS
// ============================================================

const app = express();

app.disable("x-powered-by");

app.use(express.json({
    limit: "64kb"
}));

app.use(express.urlencoded({
    extended: false,
    limit: "64kb"
}));

// ============================================================
// STATE
// ============================================================

const tasks = new Map();

const queue = [];

let activeBrowsers = 0;

let schedulerRunning = false;

let shuttingDown = false;

// ============================================================
// STATUS
// ============================================================

const TERMINAL_STATES = new Set([
    "done",
    "error",
    "timeout",
    "browser_error",
    "queue_timeout",
    "cancelled"
]);

function isTerminal(status) {
    return TERMINAL_STATES.has(status);
}

// ============================================================
// SAFE TIMER
// ============================================================

function safeClearTimer(timer) {

    if (timer) {
        clearTimeout(timer);
    }
}

// ============================================================
// WITH TIMEOUT
// ============================================================

async function withTimeout(
    promise,
    timeout,
    message
) {

    let timer = null;

    try {

        return await Promise.race([

            promise,

            new Promise((_, reject) => {

                timer = setTimeout(() => {

                    reject(
                        new Error(
                            message ||
                            `Operation timeout after ${timeout}ms`
                        )
                    );

                }, timeout);

            })

        ]);

    } finally {

        safeClearTimer(timer);
    }
}

// ============================================================
// TASK ID
// ============================================================

function createTaskId() {

    return (
        Date.now().toString(36) +
        "-" +
        Math.random()
            .toString(36)
            .slice(2, 8)
    );
}

// ============================================================
// TASK RESULT
// ============================================================

function setTaskResult(
    task,
    status,
    message,
    extra = {}
) {

    if (!task) {
        return;
    }

    // Jangan overwrite hasil terminal
    // kecuali task masih aktif.
    if (isTerminal(task.status)) {
        return;
    }

    task.status = status;

    task.result = {
        status,
        message,
        ...extra
    };

    task.completedAt = Date.now();
}

// ============================================================
// BROWSER CLEANUP
// ============================================================

async function safeClosePage(page) {

    if (!page) {
        return;
    }

    try {

        if (
            typeof page.isClosed === "function" &&
            page.isClosed()
        ) {
            return;
        }

        await withTimeout(
            page.close(),
            CLEANUP_TIMEOUT,
            "Page close timeout"
        );

    } catch {
        // Ignore.
    }
}

// ============================================================
// BROWSER CLOSE
// ============================================================

async function safeCloseBrowser(browser) {

    if (!browser) {
        return;
    }

    try {

        await withTimeout(
            browser.close(),
            CLEANUP_TIMEOUT,
            "Browser close timeout"
        );

    } catch {
        // Browser mungkin sudah crash.
    }
}

// ============================================================
// FORCE CLEANUP
// ============================================================

async function destroyBrowser(
    browser,
    page
) {

    // Page dulu
    await safeClosePage(page);

    // Browser
    await safeCloseBrowser(browser);

    // Berikan sedikit kesempatan event loop
    // membersihkan reference.
    await new Promise(
        resolve => setImmediate(resolve)
    );
}

// ============================================================
// AUTH
// ============================================================

function authenticate(req, res) {

    if (!AUTH_TOKEN) {
        return true;
    }

    const authHeader =
        req.headers.authorization || "";

    const bearer =
        authHeader.startsWith("Bearer ")
            ? authHeader.slice(7)
            : null;

    const supplied =
        bearer ||
        req.headers["x-auth-token"];

    if (supplied !== AUTH_TOKEN) {

        res.status(401).json({
            status: "error",
            message: "Unauthorized"
        });

        return false;
    }

    return true;
}

// ============================================================
// VALIDATION
// ============================================================

const ALLOWED_TYPES = new Set([
    "turnstile",
    "recaptcha2",
    "recaptcha3",
    "interstitial"
]);

// ============================================================
// SOLVER DISPATCH
// ============================================================

async function runSolver(
    item,
    page
) {

    switch (item.type) {

        case "turnstile":

            return require(
                "./Api/turnstile"
            )(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    proxy: item.proxy
                },
                page
            );

        case "recaptcha2":

            return require(
                "./Api/recaptcha2"
            )(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    isInvisible: item.isInvisible,
                    proxy: item.proxy
                },
                page
            );

        case "recaptcha3":

            return require(
                "./Api/recaptcha3"
            )(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    proxy: item.proxy
                },
                page
            );

        case "interstitial":

            return require(
                "./Api/interstitial"
            )(
                {
                    domain: item.domain,
                    proxy: item.proxy
                },
                page
            );

        default:

            throw new Error(
                "Invalid solver type"
            );
    }
}

// ============================================================
// QUEUE TIMEOUT WATCHDOG
// ============================================================

function startQueueWatchdog(
    taskId
) {

    const task =
        tasks.get(taskId);

    if (!task) {
        return;
    }

    task.queueTimer =
        setTimeout(() => {

            const current =
                tasks.get(taskId);

            if (!current) {
                return;
            }

            // Kalau sudah mendapat browser,
            // jangan ganggu.
            if (
                current.status !== "pending"
            ) {
                return;
            }

            // Hapus task dari queue.
            const index =
                queue.findIndex(
                    x => x.taskId === taskId
                );

            if (index !== -1) {
                queue.splice(index, 1);
            }

            setTaskResult(
                current,
                "queue_timeout",
                "Task menunggu terlalu lama. Silakan coba lagi."
            );

            current.queueTimer = null;

            console.log(
                `[${taskId}] queue timeout`
            );

        },
        QUEUE_TIMEOUT
    );
}

// ============================================================
// EXECUTE TASK
// ============================================================

async function executeTask(item) {

    const task =
        tasks.get(item.taskId);

    if (!task) {
        return;
    }

    // Task mungkin sudah timeout ketika
    // menunggu queue.
    if (
        task.status !== "pending"
    ) {
        return;
    }

    safeClearTimer(
        task.queueTimer
    );

    task.queueTimer = null;

    task.status = "processing";

    task.startedAt = Date.now();

    let browser = null;
    let page = null;

    let browserTimer = null;

    let finished = false;

    try {

        console.log(
            `[${item.taskId}] start ${item.type}`
        );

        // ----------------------------------------------------
        // Browser watchdog
        // ----------------------------------------------------

        const browserTimeout =
            new Promise((_, reject) => {

                browserTimer =
                    setTimeout(() => {

                        reject(
                            Object.assign(
                                new Error(
                                    "Browser/solver timeout after 120 seconds"
                                ),
                                {
                                    code:
                                        "BROWSER_TIMEOUT"
                                }
                            )
                        );

                    },
                    BROWSER_TIMEOUT);

            });

        // ----------------------------------------------------
        // Browser options
        // ----------------------------------------------------

        const options = {

            headless: false,

            turnstile: true,

            connectOption: {
                defaultViewport: null
            },

            disableXvfb: false
        };

        if (
            item.proxy &&
            item.proxy.server
        ) {

            options.args = [
                `--proxy-server=${item.proxy.server}`
            ];
        }

        // ----------------------------------------------------
        // Launch browser
        // ----------------------------------------------------

        const browserLaunch =
            connect(options);

        const connected =
            await Promise.race([

                browserLaunch,

                new Promise((_, reject) => {

                    setTimeout(() => {

                        reject(
                            Object.assign(
                                new Error(
                                    "Browser launch timeout"
                                ),
                                {
                                    code:
                                        "LAUNCH_TIMEOUT"
                                }
                            )
                        );

                    },
                    LAUNCH_TIMEOUT);

                })

            ]);

        browser =
            connected.browser;

        page =
            connected.page;

        if (!browser || !page) {

            throw Object.assign(
                new Error(
                    "Browser connection failed"
                ),
                {
                    code:
                        "BROWSER_ERROR"
                }
            );
        }

        // ----------------------------------------------------
        // Browser crash detection
        // ----------------------------------------------------

        if (
            browser &&
            typeof browser.on === "function"
        ) {

            browser.on(
                "disconnected",
                () => {

                    if (!finished) {

                        console.log(
                            `[${item.taskId}] browser disconnected`
                        );
                    }
                }
            );
        }

        // ----------------------------------------------------
        // Proxy authentication
        // ----------------------------------------------------

        if (
            item.proxy?.username &&
            item.proxy?.password
        ) {

            await page.authenticate({
                username:
                    item.proxy.username,
                password:
                    item.proxy.password
            });
        }

        // ----------------------------------------------------
        // Start solver
        //
        // IMPORTANT:
        // The solver itself remains external.
        // This API only controls its lifetime.
        // ----------------------------------------------------

        const solverPromise =
            runSolver(
                item,
                page
            );

        const result =
            await Promise.race([

                solverPromise,

                browserTimeout

            ]);

        // ----------------------------------------------------
        // SUCCESS
        // ----------------------------------------------------

        finished = true;

        safeClearTimer(
            browserTimer
        );

        browserTimer = null;

        const current =
            tasks.get(item.taskId);

        if (current) {

            current.status = "done";

            current.result = {
                status: "done",
                ...(result || {})
            };

            current.completedAt =
                Date.now();
        }

        console.log(
            `[${item.taskId}] done`
        );

    } catch (err) {

        finished = true;

        safeClearTimer(
            browserTimer
        );

        browserTimer = null;

        const current =
            tasks.get(item.taskId);

        if (!current) {
            return;
        }

        const code =
            err?.code || "";

        if (
            code === "BROWSER_TIMEOUT"
        ) {

            setTaskResult(
                current,
                "timeout",
                "Browser tidak berhasil menyelesaikan task dalam 2 menit. Silakan coba lagi."
            );

            console.log(
                `[${item.taskId}] timeout`
            );

        } else if (
            code === "LAUNCH_TIMEOUT"
        ) {

            setTaskResult(
                current,
                "browser_error",
                "Browser gagal dibuka. Silakan coba lagi."
            );

            console.log(
                `[${item.taskId}] launch error`
            );

        } else {

            setTaskResult(
                current,
                "error",
                err?.message ||
                "Task gagal diselesaikan."
            );

            console.log(
                `[${item.taskId}] error`
            );
        }

    } finally {

        // ----------------------------------------------------
        // HARD CLEANUP
        //
        // Browser HARUS dibersihkan sebelum slot
        // dikembalikan ke queue.
        // ----------------------------------------------------

        safeClearTimer(
            browserTimer
        );

        await destroyBrowser(
            browser,
            page
        );

        const current =
            tasks.get(item.taskId);

        if (current) {

            current.browserClosedAt =
                Date.now();
        }

        // Pastikan queue diproses setelah cleanup.
    }
}

// ============================================================
// QUEUE SCHEDULER
// ============================================================

function processQueue() {

    if (shuttingDown) {
        return;
    }

    if (schedulerRunning) {
        return;
    }

    schedulerRunning = true;

    try {

        while (
            queue.length > 0 &&
            activeBrowsers < MAX_BROWSERS
        ) {

            const item =
                queue.shift();

            const task =
                tasks.get(item.taskId);

            if (!task) {
                continue;
            }

            // Task sudah timeout ketika menunggu
            if (
                task.status !== "pending"
            ) {
                continue;
            }

            safeClearTimer(
                task.queueTimer
            );

            task.queueTimer = null;

            activeBrowsers++;

            // ------------------------------------------------
            // Jalankan task.
            //
            // Slot browser tetap dihitung sampai
            // executeTask() selesai DAN cleanup selesai.
            // ------------------------------------------------

            executeTask(item)
                .catch(() => {})
                .finally(() => {

                    activeBrowsers--;

                    if (
                        activeBrowsers < 0
                    ) {
                        activeBrowsers = 0;
                    }

                    // Cari task berikutnya
                    processQueue();
                });
        }

    } finally {

        schedulerRunning = false;
    }
}

// ============================================================
// CREATE TASK
// ============================================================

function createTask(data) {

    const taskId =
        createTaskId();

    const task = {

        taskId,

        status: "pending",

        createdAt:
            Date.now(),

        startedAt: null,

        completedAt: null,

        browserClosedAt: null,

        queueTimer: null,

        result: null
    };

    tasks.set(
        taskId,
        task
    );

    queue.push({

        taskId,

        type: data.type,

        domain: data.domain,

        siteKey: data.siteKey,

        action: data.action,

        proxy: data.proxy,

        isInvisible:
            data.isInvisible
    });

    startQueueWatchdog(
        taskId
    );

    return taskId;
}

// ============================================================
// REMOVE TASK FROM QUEUE
// ============================================================

function removeFromQueue(taskId) {

    for (
        let i = queue.length - 1;
        i >= 0;
        i--
    ) {

        if (
            queue[i].taskId === taskId
        ) {

            queue.splice(i, 1);
        }
    }
}

// ============================================================
// CLEAN OLD TASKS
// ============================================================

function cleanupTasks() {

    const now =
        Date.now();

    for (
        const [taskId, task]
        of tasks
    ) {

        if (
            isTerminal(task.status) &&
            task.completedAt &&
            now - task.completedAt >
                RESULT_TTL
        ) {

            safeClearTimer(
                task.queueTimer
            );

            removeFromQueue(
                taskId
            );

            tasks.delete(
                taskId
            );
        }
    }
}

setInterval(
    cleanupTasks,
    60 * 1000
);

// ============================================================
// HEALTH
// ============================================================

app.get(
    "/",
    (req, res) => {

        const memory =
            process.memoryUsage();

        res.json({

            status: "running",

            server: {

                version:
                    "super-robust-1.0",

                uptime:
                    Math.floor(
                        process.uptime()
                    ),

                maxBrowsers:
                    MAX_BROWSERS,

                maxQueue:
                    MAX_QUEUE,

                activeBrowsers,

                queueLength:
                    queue.length,

                taskCount:
                    tasks.size
            },

            limits: {

                queueTimeout:
                    `${QUEUE_TIMEOUT / 1000}s`,

                browserTimeout:
                    `${BROWSER_TIMEOUT / 1000}s`,

                cleanupTimeout:
                    `${CLEANUP_TIMEOUT / 1000}s`
            },

            memory: {

                rss:
                    `${Math.round(
                        memory.rss /
                        1024 /
                        1024
                    )} MB`,

                heapUsed:
                    `${Math.round(
                        memory.heapUsed /
                        1024 /
                        1024
                    )} MB`,

                heapTotal:
                    `${Math.round(
                        memory.heapTotal /
                        1024 /
                        1024
                    )} MB`,

                external:
                    `${Math.round(
                        memory.external /
                        1024 /
                        1024
                    )} MB`
            }
        });
    }
);

// ============================================================
// SOLVE
// ============================================================

app.post(
    "/solve",
    async (req, res) => {

        if (!authenticate(req, res)) {
            return;
        }

        if (shuttingDown) {

            return res.status(503).json({
                status: "error",
                message:
                    "Server sedang shutdown."
            });
        }

        const {
            type,
            domain,
            siteKey,
            taskId,
            action,
            proxy,
            isInvisible
        } = req.body;

        // ====================================================
        // POLL EXISTING TASK
        // ====================================================

        if (taskId) {

            const task =
                tasks.get(taskId);

            if (!task) {

                return res.status(404).json({

                    status:
                        "error",

                    message:
                        "Task tidak ditemukan atau sudah expired."
                });
            }

            // -----------------------------
            // Still waiting
            // -----------------------------

            if (
                task.status === "pending"
            ) {

                const waited =
                    Date.now() -
                    task.createdAt;

                const remaining =
                    Math.max(
                        0,
                        QUEUE_TIMEOUT -
                        waited
                    );

                return res.json({

                    status:
                        "pending",

                    message:
                        "Task sedang mengantre.",

                    queuePosition:
                        Math.max(
                            1,
                            queue.findIndex(
                                x =>
                                    x.taskId ===
                                    taskId
                            ) + 1
                        ),

                    waitSeconds:
                        Math.floor(
                            waited / 1000
                        ),

                    remainingSeconds:
                        Math.ceil(
                            remaining / 1000
                        )
                });
            }

            // -----------------------------
            // Processing
            // -----------------------------

            if (
                task.status === "processing"
            ) {

                const elapsed =
                    task.startedAt
                        ? Date.now() -
                          task.startedAt
                        : 0;

                const remaining =
                    Math.max(
                        0,
                        BROWSER_TIMEOUT -
                        elapsed
                    );

                return res.json({

                    status:
                        "processing",

                    message:
                        "Task sedang diproses.",

                    elapsedSeconds:
                        Math.floor(
                            elapsed / 1000
                        ),

                    remainingSeconds:
                        Math.ceil(
                            remaining / 1000
                        )
                });
            }

            // -----------------------------
            // TERMINAL RESULT
            // -----------------------------

            if (
                isTerminal(
                    task.status
                )
            ) {

                const response =
                    task.result || {
                        status:
                            task.status
                    };

                // Result sudah diambil.
                // Hapus task SEKARANG.
                tasks.delete(
                    taskId
                );

                safeClearTimer(
                    task.queueTimer
                );

                return res.json(
                    response
                );
            }

            return res.json({
                status:
                    task.status
            });
        }

        // ====================================================
        // VALIDATION
        // ====================================================

        if (!type || !domain) {

            return res.status(400).json({

                status: "error",

                message:
                    "Missing type or domain"
            });
        }

        if (
            !ALLOWED_TYPES.has(type)
        ) {

            return res.status(400).json({

                status: "error",

                message:
                    "Invalid solver type"
            });
        }

        if (
            (
                type === "turnstile" ||
                type === "recaptcha2" ||
                type === "recaptcha3"
            ) &&
            !siteKey
        ) {

            return res.status(400).json({

                status: "error",

                message:
                    "Missing siteKey"
            });
        }

        // ====================================================
        // QUEUE LIMIT
        // ====================================================

        if (
            queue.length >= MAX_QUEUE
        ) {

            return res.status(503).json({

                status:
                    "queue_full",

                message:
                    "Server sedang penuh. Coba lagi beberapa saat."
            });
        }

        // ====================================================
        // CREATE
        // ====================================================

        const newTaskId =
            createTask({

                type,
                domain,
                siteKey,
                action,
                proxy,
                isInvisible
            });

        console.log(
            `[${newTaskId}] queued`
        );

        // ====================================================
        // START QUEUE
        // ====================================================

        processQueue();

        // ====================================================
        // RESPONSE
        // ====================================================

        return res.status(200).json({

            status:
                "pending",

            taskId:
                newTaskId,

            message:
                activeBrowsers <
                MAX_BROWSERS
                    ? "Task diterima dan sedang diproses."
                    : "Task diterima dan sedang mengantre.",

            queuePosition:
                Math.max(
                    1,
                    queue.findIndex(
                        x =>
                            x.taskId ===
                            newTaskId
                    ) + 1
                ),

            maxWaitSeconds:
                QUEUE_TIMEOUT / 1000
        });
    }
);

// ============================================================
// 404
// ============================================================

app.use(
    (req, res) => {

        res.status(404).json({

            status:
                "error",

            message:
                "Not Found"
        });
    }
);

// ============================================================
// SHUTDOWN
// ============================================================

async function shutdown(
    signal
) {

    if (shuttingDown) {
        return;
    }

    shuttingDown = true;

    console.log(
        `${signal} received. Shutting down...`
    );

    // Semua task yang masih pending
    for (
        const task of tasks.values()
    ) {

        if (
            task.status === "pending"
        ) {

            safeClearTimer(
                task.queueTimer
            );

            task.status =
                "cancelled";

            task.result = {

                status:
                    "cancelled",

                message:
                    "Server sedang shutdown."
            };

            task.completedAt =
                Date.now();
        }
    }

    queue.length = 0;

    // Tunggu browser aktif selesai
    // maksimal 15 detik.
    const started =
        Date.now();

    while (
        activeBrowsers > 0 &&
        Date.now() - started <
            15000
    ) {

        await new Promise(
            resolve =>
                setTimeout(
                    resolve,
                    250
                )
        );
    }

    process.exit(0);
}

process.on(
    "SIGTERM",
    () => shutdown("SIGTERM")
);

process.on(
    "SIGINT",
    () => shutdown("SIGINT")
);

// ============================================================
// UNHANDLED ERRORS
// ============================================================

process.on(
    "unhandledRejection",
    err => {

        console.error(
            "Unhandled rejection:",
            err?.message || err
        );
    }
);

process.on(
    "uncaughtException",
    err => {

        console.error(
            "Uncaught exception:",
            err?.message || err
        );
    }
);

// ============================================================
// START
// ============================================================

const server =
    app.listen(
        PORT,
        () => {

            console.log(
                `Server running on ${PORT}`
            );

            console.log(
                `Browsers: ${MAX_BROWSERS}`
            );

            console.log(
                `Queue: ${MAX_QUEUE}`
            );

            console.log(
                `Queue timeout: ${QUEUE_TIMEOUT / 1000}s`
            );

            console.log(
                `Browser timeout: ${BROWSER_TIMEOUT / 1000}s`
            );
        }
    );

server.on(
    "error",
    err => {

        console.error(
            "Server error:",
            err?.message || err
        );
    }
);
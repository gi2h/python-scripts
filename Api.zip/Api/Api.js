/**
 * Api.js — v4.8 FINAL (Full URL Path + Robust Solver Dispatch + DNS Bypass)
 */

"use strict";

// ── [v4.4] Paksa Node.js prefer IPv4 ──────────────────────
const dns = require("dns");
try { dns.setDefaultResultOrder("ipv4first"); } catch {}

const express = require("express");
const { connect } = require("puppeteer-real-browser");

// ============================================================
// CONFIG
// ============================================================
const PORT = Number(process.env.PORT || 8080);
const AUTH_TOKEN = process.env.authToken || null;

const MAX_BROWSERS = 2;
const MAX_QUEUE = 4;
const QUEUE_TIMEOUT = 60 * 1000;
const BROWSER_TIMEOUT = 180 * 1000;
const CLEANUP_TIMEOUT = 10 * 1000;
const RESULT_TTL = 5 * 60 * 1000;
const LAUNCH_TIMEOUT = 40 * 1000;
const WARMUP_TIMEOUT = 8 * 1000;

global.timeOut = Number(process.env.SOLVER_TIMEOUT || 120000);

// ============================================================
// EXPRESS
// ============================================================
const app = express();
app.disable("x-powered-by");
app.use(express.json({ limit: "64kb" }));
app.use(express.urlencoded({ extended: false, limit: "64kb" }));

// ============================================================
// STATE
// ============================================================
const tasks = new Map();
const queue = [];
let activeBrowsers = 0;
let schedulerRunning = false;
let shuttingDown = false;

const TERMINAL_STATES = new Set([
    "done", "error", "timeout", "browser_error",
    "queue_timeout", "cancelled"
]);

function isTerminal(status) {
    return TERMINAL_STATES.has(status);
}

// ============================================================
// HELPERS
// ============================================================
function safeClearTimer(timer) { if (timer) clearTimeout(timer); }

async function withTimeout(promise, timeout, message) {
    let timer = null;
    try {
        return await Promise.race([
            promise,
            new Promise((_, reject) => {
                timer = setTimeout(() => {
                    reject(new Error(message || `Operation timeout after ${timeout}ms`));
                }, timeout);
            })
        ]);
    } finally {
        safeClearTimer(timer);
    }
}

function createTaskId() {
    return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2, 8);
}

function setTaskResult(task, status, message, extra = {}) {
    if (!task) return;
    if (isTerminal(task.status)) return;
    task.status = status;
    task.result = { status, message, ...extra };
    task.completedAt = Date.now();
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// ============================================================
// CLEANUP
// ============================================================
async function safeClosePage(page) {
    if (!page) return;
    try {
        if (typeof page.isClosed === "function" && page.isClosed()) return;
        await withTimeout(page.close(), CLEANUP_TIMEOUT, "Page close timeout");
    } catch {}
}

async function safeCloseBrowser(browser) {
    if (!browser) return;
    try {
        await withTimeout(browser.close(), CLEANUP_TIMEOUT, "Browser close timeout");
    } catch {}
}

async function destroyBrowser(browser, page) {
    await safeClosePage(page);
    await safeCloseBrowser(browser);
    await new Promise(resolve => setImmediate(resolve));
}

// ============================================================
// AUTH
// ============================================================
function authenticate(req, res) {
    if (!AUTH_TOKEN) return true;
    const authHeader = req.headers.authorization || "";
    const bearer = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : null;
    const supplied = bearer || req.headers["x-auth-token"];
    if (supplied !== AUTH_TOKEN) {
        res.status(401).json({ status: "error", message: "Unauthorized" });
        return false;
    }
    return true;
}

// ============================================================
// VALIDATION (FIXED: Mempertahankan Path URL)
// ============================================================
const ALLOWED_TYPES = new Set([
    "turnstile", "recaptcha2", "recaptcha3", "interstitial"
]);

function normalizeUrl(url) {
    if (!url || typeof url !== "string") return null;
    let d = url.trim();
    if (!/^https?:\/\//i.test(d)) d = "https://" + d;
    try {
        const u = new URL(d);
        return u.href; // Mengembalikan URL lengkap, termasuk path
    } catch { return null; }
}

// ============================================================
// [v4.4] ROBUST SOLVER LOADER — auto-detect path
// ============================================================
function requireSolver(name) {
    const candidates = [
        `./${name}`,          // /app/Api/turnstile.js
        `./Api/${name}`,      // /app/Api/Api/turnstile.js
        `./solvers/${name}`,  // fallback
        `./src/${name}`,      // fallback
    ];
    let lastErr = null;
    for (const p of candidates) {
        try {
            const m = require(p);
            console.log(`[loader] ✅ loaded ${name} from ${p}`);
            return m;
        } catch (e) {
            if (e.code === "MODULE_NOT_FOUND" && e.message.includes(name)) {
                lastErr = e;
                continue;
            }
            throw e;
        }
    }
    throw lastErr || new Error(`Solver "${name}" tidak ditemukan di manapun`);
}

// ============================================================
// [v4.7] SOLVER DISPATCH (FIXED)
// ============================================================
async function runSolver(item, page) {
    const solverModule = requireSolver(item.type);
    const solverFn = solverModule.default || solverModule; 
    
    if (typeof solverFn !== "function") {
        throw new Error(`Solver "${item.type}" tidak mengembalikan fungsi`);
    }

    switch (item.type) {
        case "turnstile":
            return solverFn(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    proxy: item.proxy
                },
                page
            );
        case "recaptcha2":
            return solverFn(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    isInvisible: item.isInvisible,
                    proxy: item.proxy
                },
                page
            );
        case "recaptcha3":
            return solverFn(
                {
                    domain: item.domain,
                    siteKey: item.siteKey,
                    action: item.action,
                    proxy: item.proxy
                },
                page
            );
        case "interstitial":
            return solverFn(
                {
                    domain: item.domain,
                    proxy: item.proxy
                },
                page
            );
        default:
            throw new Error("Invalid solver type");
    }
}

// ============================================================
// QUEUE WATCHDOG
// ============================================================
function startQueueWatchdog(taskId) {
    const task = tasks.get(taskId);
    if (!task) return;
    task.queueTimer = setTimeout(() => {
        const current = tasks.get(taskId);
        if (!current || current.status !== "pending") return;
        const idx = queue.findIndex(x => x.taskId === taskId);
        if (idx !== -1) queue.splice(idx, 1);
        setTaskResult(current, "queue_timeout",
            "Task menunggu terlalu lama. Silakan coba lagi.");
        current.queueTimer = null;
        console.log(`[${taskId}] queue timeout`);
    }, QUEUE_TIMEOUT);
}

// ============================================================
// [v4.6] BROWSER ARGS — HARDCODE HOST RESOLVER (DNS BYPASS)
// ============================================================
function buildBrowserArgs(proxy) {
    const args = [
        "--disable-blink-features=AutomationControlled",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-infobars",
        "--disable-notifications",
        "--disable-popup-blocking",
        "--window-position=0,0",
        "--force-device-scale-factor=1",

        "--enable-features=NetworkService,NetworkServiceInProcess",
        "--enable-quic",
        "--enable-http2",

        "--use-gl=angle",
        "--use-angle=swiftshader",
        "--enable-webgl",
        "--enable-webgl2-compute-context",
        "--enable-accelerated-2d-canvas",
        "--ignore-gpu-blocklist",
        "--enable-gpu-rasterization",
        "--enable-zero-copy",

        "--window-size=1366,768",
        "--lang=en-US,en",

        "--no-sandbox",
        "--disable-setuid-sandbox",
        "--disable-dev-shm-usage",

        "--disable-background-networking",
        "--disable-background-timer-throttling",
        "--disable-backgrounding-occluded-windows",
        "--disable-renderer-backgrounding",
        "--disable-ipc-flooding-protection",
        "--js-flags=--max-old-space-size=256",

        // ── [v4.6] FIX DNS OVERRIDE (BYPASS RAILWAY DNS) ──
        "--host-resolver-rules=MAP challenges.cloudflare.com 104.16.132.229, MAP *.challenges.cloudflare.com 104.16.132.229",
        "--dns-over-https-mode=secure",
        "--dns-over-https-templates=https://cloudflare-dns.com/dns-query",
        "--enable-features=DnsOverHttps"
    ];

    if (proxy && proxy.server) {
        args.push(`--proxy-server=${proxy.server}`);
    }
    return args;
}

// ============================================================
// [v4.4] LOGGERS — filter noise
// ============================================================
function attachDebugLoggers(page, taskId) {
    try {
        page.on("console", (msg) => {
            try {
                const text = msg.text();
                const type = msg.type();

                if (text.includes("Failed to load resource") ||
                    text.includes("favicon") ||
                    text.includes("postMessage") ||
                    text.includes("404") ||
                    text.includes("net::ERR")) {
                    return;
                }

                if (type === "error" ||
                    text.includes("[ts]") ||
                    text.includes("turnstile") ||
                    text.includes("challenge")) {
                    console.log(`[browser:${type}] ${text.slice(0, 250)}`);
                }
            } catch {}
        });

        page.on("pageerror", (err) => {
            const m = (err && err.message) || String(err);
            if (m.includes("postMessage") || m.includes("DOMWindow")) return;
            console.log(`[browser:pageerror] ${m.slice(0, 200)}`);
        });

        page.on("requestfailed", (req) => {
            try {
                const url = req.url();
                if (url.includes("favicon")) return;
                const fail = req.failure();
                const errText = fail ? fail.errorText : "unknown";

                let kategori = "OTHER";
                if (url.includes("cdn-cgi/challenge-platform")) kategori = "BOT_MGMT";
                else if (url.includes("turnstile")) kategori = "TURNSTILE";
                else if (url.includes("challenges.cloudflare.com")) kategori = "CF_OTHER";

                console.log(`[REQFAIL] ${kategori} err=${errText} url=${url.slice(0, 100)}`);
            } catch {}
        });

        page.on("error", (err) => {
            console.log(`[${taskId}] page error: ${err.message}`);
        });
    } catch (e) {
        console.log(`[${taskId}] log attach warning: ${e.message}`);
    }
}

// ============================================================
// [v4.4] WARM-UP
// ============================================================
async function warmUpPage(page, proxy) {
    try {
        await page.setUserAgent(
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Safari/537.36"
        );
    } catch {}

    try {
        await page.setViewport({ width: 1366, height: 768, deviceScaleFactor: 1 });
    } catch {}

    try {
        await page.setExtraHTTPHeaders({
            "Accept-Language": "en-US,en;q=0.9",
            "sec-ch-ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"'
        });
    } catch {}

    if (proxy && proxy.username && proxy.password) {
        try {
            await page.authenticate({
                username: proxy.username,
                password: proxy.password
            });
        } catch {}
    }

    try {
        await withTimeout(
            page.goto("about:blank", { waitUntil: "domcontentloaded" }),
            WARMUP_TIMEOUT,
            "Warmup timeout"
        );
    } catch {}
}

// ============================================================
// EXECUTE TASK
// ============================================================
async function executeTask(item) {
    const task = tasks.get(item.taskId);
    if (!task || task.status !== "pending") return;

    safeClearTimer(task.queueTimer);
    task.queueTimer = null;
    task.status = "processing";
    task.startedAt = Date.now();

    let browser = null;
    let page = null;
    let browserTimer = null;
    let finished = false;

    try {
        console.log(`[${item.taskId}] start ${item.type}`);

        const browserTimeout = new Promise((_, reject) => {
            browserTimer = setTimeout(() => {
                reject(Object.assign(
                    new Error("Browser/solver timeout"),
                    { code: "BROWSER_TIMEOUT" }
                ));
            }, BROWSER_TIMEOUT);
        });

        const options = {
            headless: false,
            connectOption: { defaultViewport: null },
            disableXvfb: false,
            turnstile: true, // Membantu klik otomatis
            args: buildBrowserArgs(item.proxy)
        };

        const browserLaunch = connect(options);
        const connected = await Promise.race([
            browserLaunch,
            new Promise((_, reject) => {
                setTimeout(() => {
                    reject(Object.assign(
                        new Error("Browser launch timeout"),
                        { code: "LAUNCH_TIMEOUT" }
                    ));
                }, LAUNCH_TIMEOUT);
            })
        ]);

        browser = connected.browser;
        page = connected.page;

        if (!browser || !page) {
            throw Object.assign(
                new Error("Browser connection failed"),
                { code: "BROWSER_ERROR" }
            );
        }

        if (typeof browser.on === "function") {
            browser.on("disconnected", () => {
                if (!finished) console.log(`[${item.taskId}] browser disconnected`);
            });
        }

        attachDebugLoggers(page, item.taskId);
        await warmUpPage(page, item.proxy);

        const solverPromise = runSolver(item, page);
        const result = await Promise.race([solverPromise, browserTimeout]);

        finished = true;
        safeClearTimer(browserTimer);
        browserTimer = null;

        const current = tasks.get(item.taskId);
        if (current) {
            current.status = "done";
            current.result = { status: "done", ...(result || {}) };
            current.completedAt = Date.now();
        }
        console.log(`[${item.taskId}] ✅ done`);

    } catch (err) {
        finished = true;
        safeClearTimer(browserTimer);
        browserTimer = null;

        const current = tasks.get(item.taskId);
        if (!current) return;

        const code = (err && err.code) || "";
        const errorMessage = (err && err.message) || "Task gagal diselesaikan.";

        console.log(`[${item.taskId}] ❌ ERROR: ${errorMessage}`);

        if (code === "BROWSER_TIMEOUT") {
            setTaskResult(current, "timeout",
                `Timeout ${BROWSER_TIMEOUT / 1000}s. Kemungkinan IP diblokir Cloudflare.`);
        } else if (code === "LAUNCH_TIMEOUT") {
            setTaskResult(current, "browser_error", "Browser gagal dibuka.");
        } else if (code === "BROWSER_ERROR") {
            setTaskResult(current, "browser_error", errorMessage);
        } else {
            setTaskResult(current, "error", errorMessage);
        }
    } finally {
        safeClearTimer(browserTimer);
        await destroyBrowser(browser, page);
        const current = tasks.get(item.taskId);
        if (current) current.browserClosedAt = Date.now();
    }
}

// ============================================================
// SCHEDULER
// ============================================================
function processQueue() {
    if (shuttingDown || schedulerRunning) return;
    schedulerRunning = true;

    try {
        while (queue.length > 0 && activeBrowsers < MAX_BROWSERS) {
            const item = queue.shift();
            const task = tasks.get(item.taskId);
            if (!task || task.status !== "pending") continue;

            safeClearTimer(task.queueTimer);
            task.queueTimer = null;
            activeBrowsers++;

            executeTask(item)
                .catch(() => {})
                .finally(() => {
                    activeBrowsers = Math.max(0, activeBrowsers - 1);
                    setImmediate(() => processQueue());
                });
        }
    } finally {
        schedulerRunning = false;
    }
}

// ============================================================
// CREATE / CLEANUP TASK
// ============================================================
function createTask(data) {
    const taskId = createTaskId();
    const task = {
        taskId,
        status: "pending",
        createdAt: Date.now(),
        startedAt: null,
        completedAt: null,
        browserClosedAt: null,
        queueTimer: null,
        result: null
    };
    tasks.set(taskId, task);
    queue.push({
        taskId,
        type: data.type,
        domain: data.domain,
        siteKey: data.siteKey,
        action: data.action,
        proxy: data.proxy,
        isInvisible: data.isInvisible
    });
    startQueueWatchdog(taskId);
    return taskId;
}

function removeFromQueue(taskId) {
    for (let i = queue.length - 1; i >= 0; i--) {
        if (queue[i].taskId === taskId) queue.splice(i, 1);
    }
}

function cleanupTasks() {
    const now = Date.now();
    for (const [taskId, task] of tasks) {
        if (isTerminal(task.status) && task.completedAt &&
            now - task.completedAt > RESULT_TTL) {
            safeClearTimer(task.queueTimer);
            removeFromQueue(taskId);
            tasks.delete(taskId);
        }
    }
}
setInterval(cleanupTasks, 60 * 1000).unref();

// ============================================================
// ROUTES
// ============================================================
app.get("/", (req, res) => {
    const memory = process.memoryUsage();
    res.json({
        status: "running",
        server: {
            version: "v4.8-fullurl-dns-fix",
            uptime: Math.floor(process.uptime()),
            maxBrowsers: MAX_BROWSERS,
            maxQueue: MAX_QUEUE,
            activeBrowsers,
            queueLength: queue.length,
            taskCount: tasks.size,
            shuttingDown
        },
        limits: {
            queueTimeout: `${QUEUE_TIMEOUT / 1000}s`,
            browserTimeout: `${BROWSER_TIMEOUT / 1000}s`,
            solverTimeout: `${global.timeOut / 1000}s`
        },
        memory: {
            rss: `${Math.round(memory.rss / 1024 / 1024)} MB`,
            heapUsed: `${Math.round(memory.heapUsed / 1024 / 1024)} MB`
        }
    });
});

app.post("/solve", async (req, res) => {
    if (!authenticate(req, res)) return;

    if (shuttingDown) {
        return res.status(503).json({
            status: "error",
            message: "Server sedang shutdown."
        });
    }

    const { type, domain, siteKey, taskId, action, proxy, isInvisible } = req.body;

    // ── Poll existing ─────────────────────────────
    if (taskId) {
        const task = tasks.get(taskId);
        if (!task) {
            return res.status(404).json({
                status: "error",
                message: "Task tidak ditemukan atau sudah expired."
            });
        }

        if (task.status === "pending") {
            const waited = Date.now() - task.createdAt;
            const remaining = Math.max(0, QUEUE_TIMEOUT - waited);
            return res.json({
                status: "pending",
                message: "Task sedang mengantre.",
                queuePosition: Math.max(1, queue.findIndex(x => x.taskId === taskId) + 1),
                waitSeconds: Math.floor(waited / 1000),
                remainingSeconds: Math.ceil(remaining / 1000)
            });
        }

        if (task.status === "processing") {
            const elapsed = task.startedAt ? Date.now() - task.startedAt : 0;
            const remaining = Math.max(0, BROWSER_TIMEOUT - elapsed);
            return res.json({
                status: "processing",
                message: "Task sedang diproses.",
                elapsedSeconds: Math.floor(elapsed / 1000),
                remainingSeconds: Math.ceil(remaining / 1000)
            });
        }

        if (isTerminal(task.status)) {
            const response = task.result || { status: task.status };
            tasks.delete(taskId);
            safeClearTimer(task.queueTimer);
            return res.json(response);
        }

        return res.json({ status: task.status });
    }

    // ── Validation ────────────────────────────────
    if (!type || !domain) {
        return res.status(400).json({
            status: "error", message: "Missing type or domain"
        });
    }

    if (!ALLOWED_TYPES.has(type)) {
        return res.status(400).json({
            status: "error", message: "Invalid solver type"
        });
    }

    if ((type === "turnstile" || type === "recaptcha2" || type === "recaptcha3")
        && !siteKey) {
        return res.status(400).json({
            status: "error", message: "Missing siteKey"
        });
    }

    // Gunakan fungsi normalizeUrl yang baru
    const normalizedUrl = normalizeUrl(domain);
    if (!normalizedUrl) {
        return res.status(400).json({
            status: "error", message: "Invalid domain"
        });
    }

    if (queue.length >= MAX_QUEUE) {
        return res.status(503).json({
            status: "queue_full",
            message: "Server sedang penuh."
        });
    }

    const newTaskId = createTask({
        type, domain: normalizedUrl, siteKey, action, proxy, isInvisible
    });

    console.log(`[${newTaskId}] queued (${type} @ ${normalizedUrl})`);
    processQueue();

    return res.status(200).json({
        status: "pending",
        taskId: newTaskId,
        message: activeBrowsers < MAX_BROWSERS
            ? "Task diterima dan sedang diproses."
            : "Task diterima dan sedang mengantre.",
        queuePosition: Math.max(1, queue.findIndex(x => x.taskId === newTaskId) + 1),
        maxWaitSeconds: QUEUE_TIMEOUT / 1000
    });
});

// 404
app.use((req, res) => {
    res.status(404).json({ status: "error", message: "Not Found" });
});

// ============================================================
// SHUTDOWN
// ============================================================
async function shutdown(signal) {
    if (shuttingDown) return;
    shuttingDown = true;
    console.log(`${signal} received. Shutting down...`);

    for (const task of tasks.values()) {
        if (task.status === "pending") {
            safeClearTimer(task.queueTimer);
            task.status = "cancelled";
            task.result = { status: "cancelled", message: "Server shutdown." };
            task.completedAt = Date.now();
        }
    }
    queue.length = 0;

    const started = Date.now();
    while (activeBrowsers > 0 && Date.now() - started < 15000) {
        await sleep(250);
    }
    process.exit(0);
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));
process.on("unhandledRejection", err => {
    console.error("Unhandled rejection:", (err && err.message) || err);
});
process.on("uncaughtException", err => {
    console.error("Uncaught exception:", (err && err.message) || err);
});

// ============================================================
// START — preflight check solver files
// ============================================================
console.log("==================================");
console.log("  Preflight check solver files...");
for (const name of ["turnstile", "recaptcha2", "recaptcha3", "interstitial"]) {
    try {
        const m = requireSolver(name);
        const fn = m.default || m;
        if (typeof fn !== "function") {
            console.log(`  ⚠️  ${name}: bukan fungsi (tipe: ${typeof fn})`);
        }
    } catch (e) {
        console.log(`  ⚠️  ${name}: ${e.message}`);
    }
}
console.log("==================================");

const server = app.listen(PORT, () => {
    console.log("==================================");
    console.log(`  Server running on ${PORT}`);
    console.log(`  Version: v4.8-fullurl-dns-fix`);
    console.log(`  Browsers: ${MAX_BROWSERS}`);
    console.log(`  Queue: ${MAX_QUEUE}`);
    console.log(`  Browser timeout: ${BROWSER_TIMEOUT / 1000}s`);
    console.log(`  Solver timeout: ${global.timeOut / 1000}s`);
    console.log("==================================");
});

server.on("error", err => {
    console.error("Server error:", (err && err.message) || err);
});